import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.css']
})
export class BarChartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  public data: any[] = [{
    kind: 'Critical'
  }, {
    kind: 'Blocker'
  },
  {
    kind: 'Major', value: 13
  }];

  public labelContent(e: any): string {
    return e.kind;
  }
}
