import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class StringToFile {
	
	private static void writeUsingFiles(String data) {
        try {
        	String home = System.getProperty("user.home");
        	String path=home+"\\Script.txt";
        	System.out.println(path);
            Files.write(Paths.get(path), data.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Done");
	}
	public static void main(String args[]) {
		String data1 = "";
		String str="";
		String requestType=args[0];
		int engineid=Integer.parseInt(args[1]);
		int containerID=Integer.parseInt(args[2]);
		int groupID=Integer.parseInt(args[3]);
		String containername ="LoadContainer";
		String groupname ="LoadGroup";
		String labname ="LoadLab";
		int containerSize=1000000000;
		int groupSize=100000000;
		for(int i=1;i<=1000;i++) {
		
		if(requestType.equalsIgnoreCase("container")){
			String data = containername+i;

			str ="curl -k --insecure -X POST \"https://sandbox-qa.labs.teradata.com/api/engines/"+engineid+"/containers\" -H  \"accept: application/json\" -H \"$TOKEN\" -H  \"Content-Type: application/json\" -d \"{\\\"request\\\":{\\\"comment\\\":\\\"Creating a database as a container.\\\"},\\\"container\\\":{\\\"container_parent\\\":\\\"DBC\\\",\\\"container_name\\\":\\\""+data+"\\\",\\\"container_size\\\":"+containerSize+",\\\"administrator_user\\\":\\\"DBC\\\",\\\"administrator_password\\\":\\\"DBC\\\",\\\"container_service_user\\\":\\\"DBC\\\",\\\"container_service_password\\\":\\\"DBC\\\",\\\"reviewers\\\":[{\\\"reviewer_id\\\":\\\"root\\\"}]}}\"";
		
		}
		
		if(requestType.equalsIgnoreCase("group")){
			
			String data = groupname+i;
			str="curl -k --insecure -X POST \"https://sandbox-qa.labs.teradata.com/api/lab/engines/"+engineid+"/containers/"+containerID+"/groups\" -H  \"accept: application/json\" -H  \"$TOKEN\" -H  \"Content-Type: application/json\" -d \"{\\\"request\\\":{\\\"comment\\\":\\\"Creating group with service defaults.\\\"},\\\"group\\\":{\\\"group_parent\\\":\\\"LoadContainer1\\\",\\\"group_name\\\":\\\""+data+"\\\",\\\"group_size\\\":"+groupSize+"}}\"";
			}
		
		if(requestType.equalsIgnoreCase("lab")){
			
			String data = labname+i;
			str="curl -k --insecure -X POST \"https://sandbox-qa.labs.teradata.com/engines/"+engineid+"/containers/"+containerID+"/groups/"+groupID+"/labs\" -H \"accept: application/json\" -H \"Content-Type: application/json\" -d \"{\\\"request\\\":{\\\"comment\\\":\\\"Creating a lab.\\\"},\\\"lab\\\":{\\\"lab_name\\\":\\\""+data+"\\\",\\\"lab_size\\\":10,\\\"lab_expiration\\\":\\\"2233-03-22T00:00:00Z\\\",\\\"reviewers\\\":[{\\\"reviewer_id\\\":\\\"root\\\"}]}}\"";
			}
		
			data1+=str+" && ";
			containerSize=10;
			groupSize=10;
		}
		writeUsingFiles(data1);
		}

}
