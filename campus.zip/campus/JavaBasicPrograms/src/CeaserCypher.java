

public class CeaserCypher {
	 public static final String ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

	    public CeaserCypher() {
	    }

	    public String encrypt(String plainText, int n) {

	        StringBuilder cipherText = new StringBuilder();

	        for (int i = 0; i < plainText.length(); i++) { // O(n)
	            char charToEncrypt = plainText.charAt(i);
	            char replaceVal = ' ';

	            if (charToEncrypt != ' ') {
	                int x = ALPHABET.indexOf(charToEncrypt);
	                int keyVal = (n + x) % 26;
	                replaceVal = ALPHABET.charAt(keyVal);
	            }

	            cipherText.append(replaceVal); // O(1) because using StringBuffer
	        }

	        return cipherText.toString();

	        // Runtime: Originally I coded this concatenating the result +=
	        //
	        //             cipherText += replaceVal;
	        //
	        // which was O(n^2) or quadratic. This isn't great for performance.
	        // By switching to a StringBuilder, we get O(1) performance when combining the strings.
	        // Which makes the overall runtime of the operation O(n) because of the for loop.
	        //
	    }

	    public String decrypt(String cipherText, int n) {

	        StringBuilder plainText = new StringBuilder();

	        for (int i = 0; i < cipherText.length(); i++) {
	            char charToDecrypt = cipherText.charAt(i);
	            char replaceVal = ' ';

	            if (charToDecrypt != ' ') {
	                int x = ALPHABET.indexOf(charToDecrypt);
	                int keyVal = (x - n) % 26;

	             /*   if (keyVal < 0) {
	                    keyVal = ALPHABET.length() + keyVal;
	                }*/

	                replaceVal = ALPHABET.charAt(keyVal);
	            }

	            plainText.append(replaceVal);
	        }

	        return plainText.toString();
	    }
	    
	    public static void main(String args[]) {
	    	CeaserCypher ch = new CeaserCypher();
	    	String res=ch.encrypt("ABC", 3);
	    	System.out.println("Encrpt "+res);
	    	String dec =ch.decrypt(res, 3);
	    	System.out.println("Decrpy "+dec);
	    }

}
