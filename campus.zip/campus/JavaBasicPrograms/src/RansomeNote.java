import java.util.HashMap;
import java.util.HashSet;

public class RansomeNote {
	
	
	void canWrite(String note,String text) {
		boolean contains =false;
		HashSet<String> hs = new HashSet<String>();
		HashSet<String> hs1 = new HashSet<String>();
		String[] ch1= note.split("");
		String[] ch2= text.split("");
		for (int i=0;i<ch2.length;i++) {
			hs.add(ch2[i]);
		}
		for (int i=0;i<ch1.length;i++) {
			if(hs.contains(ch1[i])) {
			contains=true;
			}else {
				hs1.add(ch1[i]);
				contains=false;
			}
		}
		System.out.println(contains);
	}
	
	void canWrt(String note,String text) {
		HashMap<String , Integer> note1 = map(note);
		HashMap<String , Integer> text2 = map(text);
		boolean res=check(note1,text2);
		System.out.println(res);
		
	}
	boolean check(HashMap<String, Integer> noteMap, HashMap<String, Integer> letterMap) {
		for (String key : noteMap.keySet()) {

            if (!letterMap.containsKey(key)) {
                return false;
            }

            int noteCount = noteMap.get(key);
            int letterCount = letterMap.get(key);

            if (letterCount < noteCount) {
                return false;
            }

        }
        return true;
	}
	HashMap<String , Integer>map(String note){
		HashMap<String , Integer> hm1 = new HashMap<String, Integer>();
		String[] ch1= note.split("");		
		for (int i=0;i<ch1.length;i++) {
			if(hm1.containsKey(ch1[i])) {
				Integer count =hm1.get(ch1[i]);
				hm1.put(ch1[i], count);
			}else
				hm1.put(ch1[i], 1);
		}
		return hm1;
	}
	public static void main(String args[]) {
		String note ="Pay me $100011";
		String text ="ayPem0001$1";
		String newNote= note.replaceAll("\\s","");
		//System.out.println(newNote);
		
		RansomeNote rn = new RansomeNote();
		//rn.canWrite(newNote,text);
		rn.canWrt(newNote, text);
	}

}
