package programs.binarytree;

public class SubTreeCheck {
	class Node{
		int data;
		Node left,right;
		Node(int data){
			this.data=data;
			left=null;
			right=null;
		}
		
	}
	
	Node root=null;
	void insert(int data) {
		root=insertR(root,data);
	}

	public Node insertR(Node root,int data) {
		
		if(root==null) {
			
			return root=new Node(data);
		}
		//System.out.println(root.data);
		if(data>root.data) {
			root.right=insertR(root.right, data);
		}
		if(data<root.data) {
			root.left=insertR(root.left, data);
		}
		
		
		return root;
		
	}
	
	String getOrder() {
		return null;
		
	}
	StringBuilder inorder(Node root,StringBuilder str1) {
		//L,ROOT,R //PREORDER :ROOT,L,R, POSTORDER:L,R,ROOT
		if(root!=null) {
		str1.append(root.data);
		inorder(root.left,str1);
		inorder(root.right,str1);
		}
		return str1;
	}
	
	String getinOrder(Node root) {
		StringBuilder str1= new StringBuilder();
		inorder(root, str1);
		return str1.toString();
	}

	
	
	public void prettyPrint() {
	    // Hard coded print out of binary tree depth = 3

	    int rootLeftKey = root.left == null ? 0 : root.left.data;
	    int rootRightKey = root.right == null ? 0 : root.right.data;

	    int rootLeftLeftKey = 0;
	    int rootLeftRightKey = 0;

	    if (root.left != null) {
	        rootLeftLeftKey = root.left.left == null ? 0 : root.left.left.data;
	        rootLeftRightKey = root.left.right == null ? 0 : root.left.right.data;
	    }

	    int rootRightLeftKey = 0;
	    int rootRightRightKey = 0;

	    if (root.right != null) {
	        rootRightLeftKey = root.right.left == null ? 0 : root.right.left.data;
	        rootRightRightKey = root.right.right == null ? 0 : root.right.right.data;
	    }

	    System.out.println("     " + root.data);
	    System.out.println("   /  \\");
	    System.out.println("  " + rootLeftKey + "    " + rootRightKey);
	    System.out.println(" / \\  / \\");
	    System.out.println(rootLeftLeftKey + "  " + rootLeftRightKey + " " + rootRightLeftKey + "   " + rootRightRightKey);
	 //   System.out.println("Root value : "+root.value);
	}
	public static void main(String args[]) {
		
		SubTreeCheck t1 = new SubTreeCheck();
		SubTreeCheck t2 = new SubTreeCheck();

        // Create our T1 tree
        t1.insert(5);
        t1.insert(3);
        t1.insert(2);
        t1.insert(4);
        t1.insert(7);
        t1.insert(6);
        t1.insert(8);
        t1.prettyPrint();
        String s1=t1.getinOrder(t1.root);
        t2.insert(7);
        t2.insert(6);
        t2.insert(8);
        t2.prettyPrint();
        String s2=t2.getinOrder(t2.root);
         if(s1.contains(s2)) {
        	System.out.println("Sub Tree True");
        }else
        	System.out.println("Sub Tree False");
        
	}
}
