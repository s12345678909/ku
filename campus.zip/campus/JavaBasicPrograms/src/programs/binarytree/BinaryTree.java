package programs.binarytree;

public class BinaryTree {
class Node{
	int data;
	Node left,right;
	Node(int data){
		this.data=data;
		left=null;
		right=null;
	}
	
}
static Node root=null;
void insert(int data) {
	root=insertR(root,data);
}

public Node insertR(Node root,int data) {
	
	if(root==null) {
		
		return root=new Node(data);
	}
	//System.out.println(root.data);
	if(data>root.data) {
		root.right=insertR(root.right, data);
	}
	if(data<root.data) {
		root.left=insertR(root.left, data);
	}
	
	
	return root;
	
}
public void search(int value) {
	if(root==null) {
		System.out.println("value not found");
	}
	Node current =root;
	while(current.data!=value) {
		if(value >current.data) {
			current=current.right;
		}else
			current=current.left;
		if(current==null) {
			System.out.println("value not found ");
			return;
		}
	}
	
		System.out.println("value found "+current.data);

}
public void prettyPrint() {
    // Hard coded print out of binary tree depth = 3

    int rootLeftKey = root.left == null ? 0 : root.left.data;
    int rootRightKey = root.right == null ? 0 : root.right.data;

    int rootLeftLeftKey = 0;
    int rootLeftRightKey = 0;

    if (root.left != null) {
        rootLeftLeftKey = root.left.left == null ? 0 : root.left.left.data;
        rootLeftRightKey = root.left.right == null ? 0 : root.left.right.data;
    }

    int rootRightLeftKey = 0;
    int rootRightRightKey = 0;

    if (root.right != null) {
        rootRightLeftKey = root.right.left == null ? 0 : root.right.left.data;
        rootRightRightKey = root.right.right == null ? 0 : root.right.right.data;
    }

    System.out.println("     " + root.data);
    System.out.println("   /  \\");
    System.out.println("  " + rootLeftKey + "    " + rootRightKey);
    System.out.println(" / \\  / \\");
    System.out.println(rootLeftLeftKey + "  " + rootLeftRightKey + " " + rootRightLeftKey + "   " + rootRightRightKey);
 //   System.out.println("Root value : "+root.value);
}

void leftview() {
	Node curr =root;
	System.out.println(curr.data);
	while(curr!=null) {
			curr=curr.left;
			System.out.println(curr.data);
			if(curr.left==null) {
				return;
			}
		
	}
	
	
	
}
void findMin() {
	Node curr =root;
	while(curr.left!=null) {
		//if(curr.data >curr.left.data) {need for non binary tree
		curr=curr.left;
	//	}
			}
	System.out.println("min value "+curr.data);
}
Node findMin(Node root) {
	Node curr =root;
	while(curr.left!=null) {
		if(curr.data >curr.left.data) {
		curr=curr.left;
		}
			}
	return curr;
}

void findMax() {
	Node curr =root;
	while(curr.right!=null) {
		if(curr.data <curr.right.data) {
		curr=curr.right;
		}
			}
	System.out.println("max value "+curr.data);
}

void inorder(Node root) {
	//L,ROOT,R //PREORDER :ROOT,L,R, POSTORDER:L,R,ROOT
	if(root!=null) {
	
	inorder(root.left);
	System.out.println(root.data);
	inorder(root.right);
	}
}
void preorder(Node root) {
	//L,ROOT,R //PREORDER :ROOT,L,R, POSTORDER:L,R,ROOT
	if(root!=null) {
	System.out.println(root.data);
	inorder(root.left);
	inorder(root.right);
	}
}
void postorder(Node root) {
	//L,ROOT,R //PREORDER :ROOT,L,R, POSTORDER:L,R,ROOT
	if(root!=null) {
	
	inorder(root.left);
	inorder(root.right);
	System.out.println(root.data);
	}
}
Node delete(Node node,int data) {
	if (node == null) {
        return null;
    }
	else if(data<node.data) {
		node.left=delete(node.left, data);
	}
	else if(data>node.data) {
		node.right=delete(node.right, data);
	}else {
		if(node.left==null && node.right==null) {
			node=null;
		}else if(node.left==null) {
			node=node.right;
		}else if(node.right==null) {
			node=node.left;
		}else {
			Node newNode =findMin(node.right);
			node.data=newNode.data;
			node.right=delete(node.right, node.data);
		}
	}
	return node;
	

}

void insert(Node node,int data) {
	node=insertR(node,data);
}

Node LCM(Node root,int n1,int n2) {
	if(root.data>n1 && root.data>n2) {
		return LCM(root.left,n1,n2);
	}
	if(root.data<n1&&root.data<n2) {
		return LCM(root.right,n1,n2);
	}
	return root;
	
}

public void prettyPrintLCM(Node node) {
    // Hard coded print out of binary tree depth = 3

    int rootLeftKey = node.left == null ? 0 : node.left.data;
    int rootRightKey = node.right == null ? 0 : node.right.data;

    int rootLeftLeftKey = 0;
    int rootLeftRightKey = 0;

    if (node.left != null) {
        rootLeftLeftKey = node.left.left == null ? 0 : node.left.left.data;
        rootLeftRightKey = node.left.right == null ? 0 : node.left.right.data;
    }

    int rootRightLeftKey = 0;
    int rootRightRightKey = 0;

    if (node.right != null) {
        rootRightLeftKey = node.right.left == null ? 0 : node.right.left.data;
        rootRightRightKey = node.right.right == null ? 0 : node.right.right.data;
    }

    System.out.println("     " + node.data);
    System.out.println("   /  \\");
    System.out.println("  " + rootLeftKey + "    " + rootRightKey);
    System.out.println(" / \\  / \\");
    System.out.println(rootLeftLeftKey + "  " + rootLeftRightKey + " " + rootRightLeftKey + "   " + rootRightRightKey);
 //   System.out.println("Root value : "+root.value);
}
public static void main(String args[]) {
	 
	BinaryTree bst1= new BinaryTree();
	bst1.insert(5);
    bst1.insert(3);
    bst1.insert(2);
    bst1.insert(4);
    bst1.insert(7);
    bst1.insert(6);
    bst1.insert(8);
    bst1.prettyPrint();
    bst1.postorder(root);
    bst1.search(8);
    bst1.findMin();
    bst1.findMax();
   // bst1.inorder(root);
    bst1.leftview();
    bst1.delete(root, 7);
    bst1.prettyPrint();
    
    //https://www.geeksforgeeks.org/lowest-common-ancestor-in-a-binary-search-tree/
    BinaryTree bst2= new BinaryTree();
    bst2.insert(20);
    bst2.insert(8);
    bst2.insert(22);
    bst2.insert(4);
    bst2.insert(12);
    bst2.insert(10);
    bst2.insert(14);
    bst2.prettyPrint();
    Node t=bst2.LCM(root, 10, 22);
    System.out.println(t.data);
    
   
   
}
}
