package programs.binarytree;

import java.util.LinkedList;
import java.util.Queue;

import programs.binarytree.SubTreeCheck.Node;

public class OddEvenDif {
//	String odd="";
//	String even="";
//	
	class Node{
		int data;
		Node left,right;
		Node(int data){
			this.data=data;
			left=null;
			right=null;
		}
		
	}
	static Node root=null;
	void insert(int data) {
		root=insertR(root,data);
	}

	public Node insertR(Node root,int data) {
		
		if(root==null) {
			
			return root=new Node(data);
		}
		//System.out.println(root.data);
		if(data>root.data) {
			root.right=insertR(root.right, data);
		}
		if(data<root.data) {
			root.left=insertR(root.left, data);
		}
		
		
		return root;
		
	}
	
	public void prettyPrint() {
	    // Hard coded print out of binary tree depth = 3

	    int rootLeftKey = root.left == null ? 0 : root.left.data;
	    int rootRightKey = root.right == null ? 0 : root.right.data;

	    int rootLeftLeftKey = 0;
	    int rootLeftRightKey = 0;

	    if (root.left != null) {
	        rootLeftLeftKey = root.left.left == null ? 0 : root.left.left.data;
	        rootLeftRightKey = root.left.right == null ? 0 : root.left.right.data;
	    }

	    int rootRightLeftKey = 0;
	    int rootRightRightKey = 0;

	    if (root.right != null) {
	        rootRightLeftKey = root.right.left == null ? 0 : root.right.left.data;
	        rootRightRightKey = root.right.right == null ? 0 : root.right.right.data;
	    }

	    System.out.println("     " + root.data);
	    System.out.println("   /  \\");
	    System.out.println("  " + rootLeftKey + "    " + rootRightKey);
	    System.out.println(" / \\  / \\");
	    System.out.println(rootLeftLeftKey + "  " + rootLeftRightKey + " " + rootRightLeftKey + "   " + rootRightRightKey);
	 //   System.out.println("Root value : "+root.value);
	}
	
	StringBuilder inorder(Node root,StringBuilder str1) {
		//L,ROOT,R //PREORDER :ROOT,L,R, POSTORDER:L,R,ROOT
		if(root!=null) {
		str1.append(root.data);
		inorder(root.left,str1);
		inorder(root.right,str1);
		}
		return str1;
	}
	
	String getinOrder(Node root) {
		StringBuilder str1= new StringBuilder();
		int n=1;
		inorder(root, str1);
	/*	if(n%2==0) {
			even =even+str1.toString();
		}
		else
			odd =odd+str1.toString();
		n++;*/
		System.out.println(str1.toString());
		return str1.toString();
	}
	
	  public int difference() {    
          int oddLevel = 0, evenLevel = 0, diffOddEven = 0;    
              
          //Variable nodesInLevel keep tracks of number of nodes in each level    
          int nodesInLevel = 0;    
              
          //Variable currentLevel keep track of level in binary tree    
          int currentLevel = 0;    
              
          //Queue will be used to keep track of nodes of tree level-wise    
          Queue<Node> queue = new LinkedList<Node>();    
              
          //Check if root is null    
          if(root == null) {    
              System.out.println("Tree is empty");    
              return 0;    
          }    
          else {    
              //Add root node to queue as it represents the first level    
              queue.add(root);    
              currentLevel++;    
                  
              while(queue.size() != 0) {    
                      
                  //Variable nodesInLevel will hold the size of queue i.e. number of elements in queue    
                  nodesInLevel = queue.size();    
                      System.out.println("SIze :"+nodesInLevel);
                  while(nodesInLevel > 0) {    
                      Node current = queue.remove();    
                          
                    //Checks if currentLevel is even or not.    
                      if(currentLevel % 2 == 0)    
                          //If level is even, add nodes's to variable evenLevel    
                          evenLevel += current.data;    
                      else    
                          //If level is odd, add nodes's to variable oddLevel    
                          oddLevel += current.data;    
                          
                      //Adds left child to queue    
                      if(current.left != null)    
                          queue.add(current.left);    
                      //Adds right child to queue    
                      if(current.right != null)     
                          queue.add(current.right);    
                     nodesInLevel--;    
                  }    
                  currentLevel++;    
              }    
              //Calculates difference between oddLevel and evenLevel    
              diffOddEven = Math.abs(oddLevel - evenLevel);    
          }    
          return diffOddEven;    
      }    

	void oddEven() {
		int odd =0;int even=0;int level=0;
		Node curr =root;
		if(level==0) {
			odd +=curr.data;
		}
		level++;
		while(level>0)
		{
		
		}
		
		
		
	}
	//recursive method
	int diff(Node root) {
		if(root==null) {
			return 0;
		}
		return root.data -diff(root.left)-diff(root.right);
	}
	void printatLevel(Node root,int level) {
		if(root==null) {
			return;
		}
		if(level==1) {
			System.out.print(root.data);
			return;
		}
		printatLevel(root.left, level-1);
		printatLevel(root.right, level-1);
		
	}
	int getHeightofBST(Node root) {
		if(root == null){
		      return -1;
		    }
		return Math.max(getHeightofBST(root.left), getHeightofBST(root.right))+1;
	}
	
	void levelAllNodes(Node root) {
		if(root == null){
		      return;
		    }
		int height =getHeightofBST(root);
		for(int i=0;i<=height;i++) {
			printatLevel(root, i+1);
		}
	}
	public static void main(String args[]) {
		 
		OddEvenDif bst1= new OddEvenDif();
		bst1.insert(5);
	    bst1.insert(3);
	    bst1.insert(2);
	    bst1.insert(4);
	    bst1.insert(7);
	    bst1.insert(6);
	    bst1.insert(8);
	    bst1.prettyPrint();
//	   int diff =bst1.difference();  //without recursion
//	   System.out.println(diff);
	   int diffRec=bst1.diff(root);
	   System.out.println("Differnece odd and even levels :"+diffRec);
	   System.out.println("Specific level : ");
	   bst1.printatLevel(root,2);
	   System.out.println();
	   System.out.println("AllNodes : ");
	   bst1.levelAllNodes(root);
	}

}
