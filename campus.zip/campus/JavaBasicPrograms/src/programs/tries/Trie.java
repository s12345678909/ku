package programs.tries;

//https://medium.com/@amogh.avadhani/how-to-build-a-trie-tree-in-java-9d144aaa0d01

//https://www.youtube.com/watch?v=-urNrIAQnNo

//https://www.youtube.com/watch?v=AXjmTQ8LEoI&t=22s&ab_channel=TusharRoy-CodingMadeSimple

import java.util.HashMap;

public class Trie {

	private TrieNode root;

	public Trie() {
		root = new TrieNode();
	}

	public void insert(String word) {
		HashMap<Character, TrieNode> children = root.getChildren();
		for(int i = 0; i < word.length(); i++) {
			char c = word.charAt(i);
			TrieNode node;
			if(children.containsKey(c)) {
				node = children.get(c);
			} else { 
				node = new TrieNode(c);
				children.put(c, node);
			}
			children = node.getChildren();

			if(i == word.length() - 1) {
				node.setLeaf(true);
			}
		}
	}

	public boolean search(String word) {
		HashMap<Character, TrieNode> children = root.getChildren();

		TrieNode node = null;
		for(int i = 0; i < word.length(); i++) {
			char c = word.charAt(i);
			if(children.containsKey(c)) {
				node = children.get(c);
				children = node.getChildren();
			} else { 
				node = null;
				break;
			}
		}

		if(node != null && node.isLeaf()) {
			return true;
		} else {
			return false;
		}
	}
	
	private boolean remove(String s) {
		 
        HashMap<Character, TrieNode> children = root.getChildren();
 
        TrieNode parent = null;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (children.containsKey(c)) {
                parent = root;
                root = children.get(c);
                children = root.getChildren();
                if (root.getChildren().equals(s)) {
 
                    parent.getChildren().remove(c);
                    root = null;
                    return true;
                }
            }
        }
        return false;
    }
public static void main(String[] args) {
		
		Trie trie = new Trie();
		trie.insert("art");
		trie.insert("bunny");
		trie.insert("buck");
		trie.insert("dog");
		trie.insert("Apostate");
		
		boolean res = trie.search("dog");
		System.out.println(res);
		trie.remove("bunny");
		boolean res1 = trie.search("dog");
		System.out.println(res1);
	}

}