package programs.tries;


//https://www.youtube.com/watch?v=Xt2ouYSxWkw   ==>not clear
public class TriesPractice {
	char c;
	TriesPractice[] childeren;
	boolean word;
	public TriesPractice() {
		this.c=0;
		this.word=false;
		childeren=new TriesPractice[26];
		
	}
	
	public void add(String s) {
		
		if(s.isEmpty()) {
			this.word=true;
			return;
		}
		
		char letter=s.charAt(0);
		int index =letter - 'a';  //to get the right index

		
		if(this.childeren[index]==null) {
			this.childeren[index]= new TriesPractice();
		}
		this.childeren[index].add(s.substring(1));
			
	}
	
	public boolean isWord(String s) {
		if(s.isEmpty()) {
			
			return this.word;
		}
		
		char letter=s.charAt(0);
		int index =letter - 'a';
		
		if(this.childeren[index]==null) {
			return false;
		}
		return this.childeren[index].isWord(s.substring(1));
			
	}

	public static void main(String args[]) {
		TriesPractice tries = new TriesPractice();
		tries.add("Tries");
		//tries.add("Try");
		
	}
}
