package programs.onenotesall;

public class GCD {
	
	 public int gcdrecurrsion(int n1,int n2) {
		 if(n2==0) {
			 return n1;
		 }else
			 return gcdrecurrsion(n2, n1%n2);
		
	}
	public static void main(String args[]) {
		GCD gcd= new GCD();
		int n1=50,n2=65;
		int res=gcd.gcdrecurrsion(n1,n2);
		System.out.println("GCD :"+res);
		int LCM= (n1*n2)/res;
		System.out.println("LCM "+LCM);
		
	}

}
