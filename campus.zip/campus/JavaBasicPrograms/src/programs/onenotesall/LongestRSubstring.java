
package programs.onenotesall;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;

import com.sun.javafx.collections.MappingChange.Map;

public class LongestRSubstring {


public static void main(String[] args) {
	LongestRSubstring sub= new LongestRSubstring();
    String test = "acbbdfghybbdf";
   // sub.test(test);
      System.out.println(sub.hasRepeatedSubString(test));
      System.out.println(sub.longestSub(test));
}

	public String hasRepeatedSubString(String string) {
    Hashtable<String, Integer> hashtable = new Hashtable<>();
    int length = string.length();
    for (int i = length - 1; i > 1; i--) {
        for (int j = 0; j <= length - i; j++) {
            String sub = string.substring(j, i + j);
            if (hashtable.containsKey(sub)) {
                return sub;
            } else {
                hashtable.put(sub, i);
            }
        }
    }
    return "No repeated substring!";
}
	
	
	//longets substring withouth repeting characters
	public void test(String test) {
		String longest=null;
		int longestlength=0;
		HashMap<Character, Integer> map = new HashMap<>();
		char a[]=test.toCharArray();
		for(int i=0;i<test.length();i++) {
			char c= a[i];
			if(!map.containsKey(c)) {
				map.put(c, i);
			}else {
				i=map.get(c);
				map.clear();
			}
			if(map.size()>longestlength) {
				longestlength=map.size();
				longest=map.keySet().toString();
			}
		}
		System.out.println(longest+longestlength);
	}
	
	//practice
	public String longestSub(String str) {
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		for(int i=str.length()-1;i>1;i--) {
			for(int j=0;j<=str.length()-i;j++) {
				String sub= str.substring(j, i+j);
				if(map.containsKey(sub)) {
					return sub;
				}
				else
					map.put(sub, i);
			}
		}
		return "No repeated substring!";
	}
}