package programs.onenotesall;
//https://www.youtube.com/watch?v=q6RicK1FCUs
public class TOH {
	
	void tower(int n,char A,char B,char C) {
		
		if(n>0) {
		tower(n-1,A,C,B);
		System.out.println("Moving Disc from "+A+ " to "+C);
		tower(n-1,B,A,C);
		}
		
	}
	
	public static void main(String args[]) {
		TOH toh= new TOH();
		int n=3;
		toh.tower(n,'A','B','C');
	}

}
