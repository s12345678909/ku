package programs.onenotesall;

public class powerusingrecursion {
	public int cal(int number,int power) {
		if(power==0) {
			return 1;
		}else {
			return number*cal(number,power-1);
		}
	}
	
	public static void main(String args[]) {
		powerusingrecursion pow= new powerusingrecursion();
		int number=2,power=4;
		int res=pow.cal(number,power);
		System.out.println(res);
		
	}

}
