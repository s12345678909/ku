package programs.onenotesall.backtracking;

public class PracticeRatMaze {
	static int N;
	
	public void print(int[][] sol) {
		for(int i=0;i<N;i++) {
			for(int j=0;j<N;j++) {
				System.out.print(sol[i][j]+" ");
			}
			System.out.println();
		}
		
	}
	public void maze(int[][] maze) {
		int[][] sol= new int[N][N];
		PracticeRatMaze find = new PracticeRatMaze();
		if(find.mazeBactracking(maze,0,0,sol)) {
			find.print(sol);
		}
	}
	
	boolean mazeBactracking(int[][]maze,int x, int y,int[][] sol) {
		if(x==N-1 && y==N-1 && maze[x][y] == 1) {
			sol[x][y]=1;
			return true;
		}
		
		if(isSafe(maze,x,y)==true && maze[x][y] == 1) {
			sol[x][y]=1;
			
			if(mazeBactracking(maze, x+1, y, sol)) {
				return true;
			}
			if(mazeBactracking(maze, x, y+1, sol)) {
				return true;
			}
			
			//if non bactracking
			sol[x][y]=0;
			return false;
		}
		return false;
		
	}
	
	
	private boolean isSafe(int[][] maze,int x,int y) {
		
		return ((x>=0 && x<N) &&(y>=0 &&y<N) && maze[x][y]==1);
	}

	public static void main(String args[]) {
	int[][] maze=   {{1, 0, 0, 0 }, 
					{ 1, 1, 0, 1 }, 
					{ 0, 1, 0, 0 }, 
					{ 1, 1, 1, 1 } }; 
		N=maze.length;
		PracticeRatMaze prc= new PracticeRatMaze();
		prc.maze(maze);
		
	}

}
