package programs.onenotesall.backtracking;

public class ArrayCombination {
	
	void combination(int[] arr,String out,int i,int len,int k) {
		if(k==0) {
			System.out.println(out);
			return;
		}
		for(int j=i;j<len;j++) {
			combination(arr, out+ " " +(arr[j]), j+1, len, k-1);
		}
		
	}
	public static void main(String args[]) {
		ArrayCombination a= new ArrayCombination();
		int k=3;
		int[] arr = { 1, 2, 3 };
		a.combination(arr, "", 0,arr.length, k);
		
	}

}
