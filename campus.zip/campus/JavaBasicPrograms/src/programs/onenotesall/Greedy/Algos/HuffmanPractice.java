package programs.onenotesall.Greedy.Algos;

//https://www.youtube.com/watch?v=HzeK7g8cD0Y  //cocept of greedy algoritm

import java.util.PriorityQueue;
import java.util.Comparator;

class HuffmanNodeP {

	int data;
	char c;

	HuffmanNodeP left;
	HuffmanNodeP right;
}

class MyComparatorP implements Comparator<HuffmanNodeP> {
	public int compare(HuffmanNodeP x, HuffmanNodeP y) {

		return x.data - y.data;
	}
}

public class HuffmanPractice {
	public static void printCode(HuffmanNodeP root, String s) {
		if (root.left == null && root.right == null && Character.isLetter(root.c)) {
			System.out.println(root.c + ":" + s);
			return;
		}
		printCode(root.left, s + "0");
		printCode(root.right, s + "1");
	}

	public static void main(String[] args) {
		int n = 6;
		char[] charArray = { 'a', 'b', 'c', 'd', 'e', 'f' };
		int[] charfreq = { 5, 9, 12, 13, 16, 45 };
		PriorityQueue<HuffmanNodeP> q = new PriorityQueue<HuffmanNodeP>(n, new MyComparatorP());
		for (int i = 0; i < n; i++) {
			HuffmanNodeP hn = new HuffmanNodeP();
			hn.c = charArray[i];
			hn.data = charfreq[i];

			hn.left = null;
			hn.right = null;

			q.add(hn);
		}

		HuffmanNodeP root = null;
		while (q.size() > 1) {
			// first min extract.
			HuffmanNodeP x = q.peek();
			q.poll();
			// second min extarct.
			HuffmanNodeP y = q.peek();
			q.poll();
			// new node f which is equal
			HuffmanNodeP f = new HuffmanNodeP();
			f.data = x.data + y.data;
			f.c = '-';
			// first extracted node as left child.
			f.left = x;
			// second extracted node as the right child.
			f.right = y;
			root = f;
			q.add(f);
		}
		printCode(root, "");
	}
}

//This code is contributed by Kunwar Desh Deepak Singh 
