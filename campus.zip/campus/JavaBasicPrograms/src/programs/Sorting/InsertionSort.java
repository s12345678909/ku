package programs.Sorting;
//https://www.youtube.com/watch?v=lCDZ0IprFw4
//fix the key at the second postion of the arry elemnt and then compare with element in left if greater than swap
public class InsertionSort {
	static int array[]= {5,3,7,8,2};
	void inssort() {
		for(int i=1;i<array.length;i++) {
			int key= array[i];
			int j=i-1;
			while(j>=0 && array[j]>key) {
				int temp=array[j];
				array[j]=key;
				array[j+1]=temp;
				j--;
			}
		}
		print();
		
		
	}
	void print() {
		for(int i=0;i<array.length;i++) {
			System.out.println(array[i]);
		}
	}
	public static void main(String args[]) {
		InsertionSort ins = new InsertionSort();
		ins.inssort();
		
	}

}
