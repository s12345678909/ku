package programs.Sorting;

public class QuickSort {
	 int[] array = {15, 3, 2, 1, 9, 5, 7, 8, 6};
	 void sort() {
		

			 quicksort( 0, array.length - 1);
			 print();
		 
	 }
	
	void quicksort(int left, int right) {
        if (left >= right) {
            return;
        }
		int pivot = array[(left+right)/2];
		
		int index = partition(left, right, pivot);
		//sort the left and right side of the array
		quicksort(left, index - 1);
        quicksort(index, right);

		
		
	}
	int partition(int left,int right,int pivot) {
		 while (left <= right) {

	            // Move left until you find an element bigger than the pivot
	            while(array[left] < pivot) {
	                left++;
	            }

	            // Move right until you find an element smaller than the pivo
	            while (array[right] > pivot) {
	                right--;
	            }

	            // Then swap
	            if (left <= right) {
	            	 int temp = array[left];
	                 array[left] = array[right];
	                 array[right] = temp;
	                left++;
	                right--;
	            }
	        }
			return left;
			
	}
	void print() {
		for( int i=0;i<array.length;i++) {
			System.out.println(array[i]);
		}
	}
	public static void main(String args[]) {
		QuickSort qs= new QuickSort();
		qs.sort();
		
	}

}
