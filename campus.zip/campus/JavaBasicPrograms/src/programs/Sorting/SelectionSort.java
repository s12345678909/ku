package programs.Sorting;
//O(n^2)
public class SelectionSort {
	static int arr[]= {5,3,7,8,2};
	
	void selsort() {

        for (int i = 0; i < arr.length; i++)  
        {  
        	
            int index = i;  
            for (int j = i + 1; j < arr.length; j++){  
                if (arr[i]>arr[j]){  
                    index = j;//searching for lowest index  
                }  //for buble sort we will swap here only i.i one by one element 
            }  
           //for selection sort we compare 1st element and swap with the smallest element in the array 
            int temp =arr[i]; 
            arr[i]=arr[index];
            arr[index]=temp;
          //  temp=arr[i];
          //  print();
        }
	}
	void print() {
		for( int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
	}
	public static void main(String args []) {
		SelectionSort bs= new SelectionSort();
		bs.selsort();
		bs.print();
		
	}
	

}
