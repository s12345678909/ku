package programs.Sorting;
//O(n^2)
public class BubbleSort {
	static int array[]= {5,3,7,8,2};
	
	void bsort() {
		for (int i=0;i<array.length;i++) {
			
			for(int j=i+1;j<array.length;j++) {
				if(array[i]>array[j]) {
					//swap logic
					int temp=array[i];
					array[i]=array[j];
					array[j]=temp;
					//temp=array[i];
	                    
					
				}
			}
		}
	}
	void bsortrecursion() {
		for (int i=0;i<array.length-1;i++) {
				if(array[i]>array[i+1]) {
					//swap logic
					  int temp = array[i+1];
	                    array[i+1] = array[i];
	                    array[i] = temp;
	                    bsort();
					
			}
		}
	}
	void print() {
		for( int i=0;i<array.length;i++) {
			System.out.println(array[i]);
		}
	}
	public static void main(String args []) {
		BubbleSort bs= new BubbleSort();
		bs.bsort();
		bs.print();
		
	}
	

}
