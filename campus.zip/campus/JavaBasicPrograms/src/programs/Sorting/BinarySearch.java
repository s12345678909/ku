package programs.Sorting;
//https://beginnersbook.com/2014/04/java-program-to-perform-binary-search/
public class BinarySearch {
	static int array[]= {1,3,7,8,9,11};
/*	void bsearch(int data) {
		//int arr =array.
		boolean flag=true;
		int first=0;
		int last=array.length-1;
		int mid=(first+last)/2;
		while(first<=last) {
			mid=first+last/2;
			if(data<array[mid]) {
				last=mid-1;
			
			}else if(data>array[mid]) {
				first=mid+1;
				
			}else if(data==array[mid]) {
				System.out.println("element found at pos "+mid);
				flag=true;
				break;
			}
			
			mid = (first + last)/2;
		}
		if(!flag) {
			System.out.println("elemnt not found");
			return;
		}
		
		
	}*/
	
	int binarySearch(int low ,int high,int data) {
		if(high>=low) {
			int mid =low +(high-low)/2;
			if(array[mid]>data) {
				return binarySearch(low, mid-1, data);
			}
			else if(array[mid]==data) {
				return mid;
			}
			
			return binarySearch(mid+1, high, data);
		}
		return -1;
	}
	public static void main(String args[]) {
		BinarySearch bs= new BinarySearch();
		//bs.bsearch(9);
		int res=bs.binarySearch(0, array.length-1, 9);
		if(res==-1) {
			System.out.println("not found");
		}
		else
			System.out.println("found at pos : "+res);
	}

}
