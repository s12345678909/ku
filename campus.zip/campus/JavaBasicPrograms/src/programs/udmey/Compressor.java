package programs.udmey;

public class Compressor {
	
	void comprssor(String str) {
		String result="";		
		String[] ch=str.split("");
		for(int i=0;i<ch.length;i++) {
			boolean flag=false;
			int count =1;
			for (int j=i+1;j<ch.length;j++) {
				if(ch[i].equalsIgnoreCase(ch[j])&& !ch[j].equalsIgnoreCase("-1")) {
					count++;
					flag=true;
					ch[j]="-1";
					
				}
			}
			if(flag) {
			result +=ch[i]+count;
			
			}
		}
		System.out.println(result);
		
	}
	 public String compress(String str) {
	        StringBuilder compressed = new StringBuilder();
	        int count = 0;
	        for (int i = 0; i < str.length(); i++) {
	            count++;

	            // If next char different, append this result
	            if (i + 1 >= str.length() || str.charAt(i) != str.charAt(i + 1)) {
	                compressed.append(str.charAt(i));
	                compressed.append(count);
	                count = 0;
	            }
	        }
	        System.out.println(compressed.toString());
	        return compressed.length() < str.length() ? compressed.toString() : str;
	    }
	
	public static void main(String args[]) {
		String str1 ="aaabbbbcc";

		Compressor pc = new Compressor();
		pc.comprssor(str1);		
		pc.compress(str1); //optimised solution
	}

}
