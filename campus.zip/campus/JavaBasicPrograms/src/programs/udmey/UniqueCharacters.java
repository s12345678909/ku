package programs.udmey;

import java.util.HashSet;

public class UniqueCharacters {
	
	void uniqueCharacters(String str) {
		HashSet<String> hs = new HashSet<String>();
		String[] s=str.split("");
		boolean flag=true;
		for(int i=0;i<s.length;i++) {
			if(hs.contains(s[i])) {
				System.out.println("Non unique character at postion :"+i+" character :"+s[i]);
				flag=false;
			}
			hs.add(s[i]);
		}
		if (flag) {
			System.out.println("Unique string");
		}
		
	}
	
	 public void isUnique(String text) {
		 boolean char_set[]= new boolean[128];
		 for (int i=0;i<text.length();i++) {
			 int value = text.charAt(i);
			 if(char_set[value]) {
				 System.out.println("dupliate at pos :"+i);
			 }
			 char_set[value]=true;
		 }
		 System.out.println("No duplicated");
	 }
	public static void main(String args[]) {
		String str ="abacdefghijklmnopqrstuvwxyz";
		UniqueCharacters uq = new UniqueCharacters();
		uq.isUnique(str);//optimised solution
		uq.uniqueCharacters(str);
		
	}

}
