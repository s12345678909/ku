package programs.udmey;

import java.util.*;
public class PermutationChecker {
	void permCheck(String str1,String str2) {
		char[] content = str2.toCharArray();
        Arrays.sort(content);
		if(str1.equalsIgnoreCase(new String(content))) {
			System.out.println("permutation true");
		}
		else
			System.out.println("perm false");
	}

	public static void main(String args[]) {
		String str1 ="abc";
		String str2 ="cba";
		PermutationChecker pc = new PermutationChecker();
		pc.permCheck(str1,str2);		
	}

}
