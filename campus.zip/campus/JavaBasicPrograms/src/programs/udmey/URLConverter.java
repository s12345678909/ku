package programs.udmey;

//Challenge: See if you can replaces all the spaces in a a string with the
// ASCII symbol for space '%20'. Assume you are given the length of the final
// string. Hint: Use array of char[]
public class URLConverter {
	 public String urlify(String url, int length) {

	        // Create a bucket to hold our final result
	        char[] result = new char[length];

	        // Strip off any space at beginning or end
	        url = url.trim();

	        // Loop through url, and insert an ASCII space '%20' whenever we hit a space
	        char[] urlChars = url.toCharArray();

	        // Also create a pointer to keep track of where we are in our results array
	        int pointer = 0;

	        for (int i=0; i < urlChars.length; i++) {

	            if (urlChars[i] != ' ') {
	                result[pointer] = urlChars[i];
	                pointer++;
	            } else {
	                result[pointer] = '%';
	                result[pointer+1] = '2';
	                result[pointer+2] = '0';
	                pointer = pointer + 3;
	            }
	          //  prettyPrint(result);
	            System.out.println("...");
	        }

	        System.out.println(String.valueOf(result));
	        return String.valueOf(result);
	    }

	    @SuppressWarnings("unused")
		private void prettyPrint(char[] chars) {
	        for (int i = 0; i < chars.length; i++) {
	            System.out.println("c[" + chars[i] + "]");
	        }
	    }
	    
	    void urlReplace(String str,int lenght) {
	    	String tes="";
	    	String strAfter=str.trim();
	    	char[] ch = new char[lenght];
	    	ch =strAfter.toCharArray();
	    	for (int i=0;i<ch.length;i++) {
	    		if(ch[i] !=' ') {
	    			tes+=ch[i];
	    		}else
	    			tes+="%20";
	    		
	    	}
	    	System.out.println(tes.trim());
	    }
	    public static void main(String args[]) {
			
			URLConverter urlConverter = new URLConverter();
			//urlConverter.urlify("My Home Page    ", 16);
			urlConverter.urlReplace("My Home Page    ", 16); //my method
			
		}
}
