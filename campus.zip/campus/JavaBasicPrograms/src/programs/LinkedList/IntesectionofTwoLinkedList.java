package programs.LinkedList;
//https://www.youtube.com/watch?v=2DZL9Ogm1Cg

import java.util.*;

public class IntesectionofTwoLinkedList
{
	
    class Node
    {
        Node next;
        int data;
        Node(int d){
        	data=d;
        	//next=null;
        }
  }
    Node head=null;
    void printList() 
    { 
        Node temp = head; 
        while (temp != null) { 
            System.out.print(temp.data + " "); 
            temp = temp.next; 
        } 
        System.out.println(); 
    } 
     public void push(int data)
    {
    	 Node newNode =new Node(data);
    	 newNode.next=head;
    	 head=newNode;
    }


   
    public IntesectionofTwoLinkedList mergeWithIntersection(Node n1, Node n2) {
    	HashSet<Integer> hs = new HashSet<Integer>();

    	IntesectionofTwoLinkedList result =new IntesectionofTwoLinkedList();
    	while(n1!=null) {
    		hs.add(n1.data);
    		n1=n1.next;
    	}
    	while(n2!=null) {
    		if(hs.contains(n2.data)) {
    			result.push(n2.data);
    			  			
    		}
    		n2=n2.next;
    	}
    	return result;

      }
    public IntesectionofTwoLinkedList Union(Node head1, Node head2) {
    	HashSet<Integer> hs = new HashSet<Integer>();
    	IntesectionofTwoLinkedList result =new IntesectionofTwoLinkedList();
    	while(head1!=null) {
    		hs.add(head1.data);
    		head1=head1.next;
    		
    	}
    	while(head2!=null) {
    		hs.add(head2.data);
    		head2=head2.next;
    	}
    	for(Integer data :hs ) {
    		result.push(data);
    		
    	}
		return result;
    	
    }

    public static void main(String[] args)
    {
    	IntesectionofTwoLinkedList a = new IntesectionofTwoLinkedList();
    	IntesectionofTwoLinkedList b = new IntesectionofTwoLinkedList();
    	IntesectionofTwoLinkedList intersection = new IntesectionofTwoLinkedList(); 
    	IntesectionofTwoLinkedList union = new IntesectionofTwoLinkedList(); 
    	a.push(20);
    	a.push(4);
    	a.push(15);
    	a.push(10);
    	b.push(10);
    	b.push(2);
    	b.push(4);
    	b.push(8);
    	a.printList();
    	b.printList();
    	intersection =intersection.mergeWithIntersection(a.head, b.head);
    	intersection.printList();
    	union =union.Union(a.head, b.head);
    	union.printList();

    }
}
