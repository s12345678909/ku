package programs.LinkedList;
//see udmey solution and other videos

public class SumTwoLinkedList
{
    public class Node
    {
        Node next;

        int data;

        Node(int data)
        {
            this.data = data;

        }
    }

    Node head;

    public void addFront(int data)
    {
        Node newNode = new Node(data);
        if (head == null)
        {
            head = newNode;
            return;
        }
        newNode.next = head;
        head = newNode;
    }

    void rotate(int k)
    {
       //add code here
       Node newHead=head;
       Node prev=null;
       for(int i=0;i<k;i++)
       {
           prev=newHead;
           newHead=newHead.next;
       }
       
       if (newHead==null) return ;
       
       Node tail=newHead;
       while(tail.next!=null) {
    	   tail=tail.next;
       }
       
       tail.next=head;
       prev.next=null;
       head=newHead;
      // return newHead;
    }
   
    void rotateMY(int data) {
    	Node current=head;
    	for(int i=1;i<data && current!=null;i++) {
    		current=current.next;
    	}
    	Node kthnode=null;
    	kthnode=current;
    	while(current.next!=null) {
    		current=current.next;
    	}
    	current.next=head;
    	head=kthnode.next;
    	kthnode.next=null;
    }
    public void print()
    {
        Node current = head;
         while (current != null)
        {
            System.out.println(current.data);
            current=current.next;
    }
    }
    static void sumTwo(Node head1,Node head2) {
    	StringBuffer sb1= new StringBuffer();
    	StringBuffer sb2= new StringBuffer();
    	Node current1=head1;
    	Node current2=head2;
    	sb1=sb1.append(current1.data);
    	while(current1.next!=null) {
    		current1=current1.next;
    		sb1=sb1.append(current1.data);
    	}
    	System.out.println("first list"+sb1);
    	sb2=sb2.append(current2.data);
    	while(current2.next!=null) {
    		current2=current2.next;
    		sb2=sb2.append(current2.data);
    	}
    	System.out.println("second list"+sb2);
    	int sum=Integer.parseInt(sb1.toString())+ Integer.parseInt(sb2.toString());
    	System.out.println("Sum :"+sum);
    	String res =Integer.toString(sum);
    	String [] value =res.split("");
    	//for (int i=0;i<value.length;i++)
    	SumTwoLinkedList ll = new SumTwoLinkedList();
    	for(String s:value) {
    		int num =Integer.parseInt(s);
    		ll.addFront(num);
    	}
    	ll.print();
    }

    public static void main(String[] args)
    {
        SumTwoLinkedList link = new SumTwoLinkedList();
        link.addFront(8);
        link.addFront(2);
        link.addFront(5);
        SumTwoLinkedList link1 = new SumTwoLinkedList();
        link1.addFront(4);
        link1.addFront(9);
        link1.addFront(2);
        sumTwo(link.head,link1.head);
        link.print();
        link1.print();
    }
}
