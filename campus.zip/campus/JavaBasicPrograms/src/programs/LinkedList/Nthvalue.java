package programs.LinkedList;
//https://www.geeksforgeeks.org/detect-loop-in-a-linked-list/

public class Nthvalue {
	 Node head;
	class Node{
		int data;
		Node next;
		public Node(int d) {
			data=d;
			next=null;
		}
	}
	public void push(int data) {
		Node newNode =new Node(data);
		newNode.next=head;
		head=newNode;
	}
	  void getNthvalue(int n) 
	    { 
		  int i=0;
	        Node temp = head; 
	        while (temp != null &&i<n ) { 
	           
	            temp = temp.next; 
	            i++;
	        } 
	        System.out.print("data at pos "+n+ "is:"+temp.data); 
	    } 
	  void getLastNthvalue(int n) //Important
	    { 
		  Node current = head;
	        Node next=null;
	        Node privious = null;
	        while(current !=null) {
	            next=current.next;
	            current.next= privious;
	            privious=current;
	            current=next;
	            
	            
	        }
	        head=privious;
	        
	        int i=0;
	        Node temp = head; 
	        while (temp != null &&i<n ) { 
	           
	            temp = temp.next; 
	            i++;
	        } 
	        System.out.print("data at pos "+n+ "is:"+temp.data); 
	    }

	  void printList() 
	    { 
	        Node temp = head; 
	        while (temp != null) { 
	            System.out.print(temp.data + " "); 
	            temp = temp.next; 
	        } 
	        System.out.println(); 
	    } 

	public static void main(String args[]) {
		Nthvalue llist = new Nthvalue();
		 llist.push(20); 
	     llist.push(4); 
	     llist.push(15); 
	     llist.push(10); 
	     llist.printList();
	     llist.getNthvalue(1);
	     System.out.println("\n");
	     llist.getLastNthvalue(1);
	}

}
