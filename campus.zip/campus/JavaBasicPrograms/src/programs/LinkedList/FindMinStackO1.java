package programs.LinkedList;

public class FindMinStackO1 {
	static int min;
	class Node {
		int data;
		Node next;
		Node(int data){
			this.data=data;
		}
	}
	Node head;
	
	void push(int data) {
		if(head ==null) {
			min=data;
		}
		if (head != null &&min>data) {
			min=data;
			
         }
		//System.out.println("min "+min);
		Node newNode = new Node(data);
		//Node temp=head;
		newNode.next=head;
		head=newNode;

	}
	void pop() {
		if(head.data<min) {
			min=head.next.data;
		}
		head=head.next;
		
	}
	
	void  min() {
		System.out.println(min);
		
		
	}
	
	public static void main(String args[]) {
		FindMinStackO1 minStack= new FindMinStackO1();
		minStack.push(0);
		minStack.push(3);
		minStack.push(1);
		minStack.push(2);
		minStack.push(9);
		
		minStack.min();
		minStack.pop();
		minStack.pop();
		minStack.pop();
		minStack.pop();
		minStack.min();
		
	}

}
