package programs.LinkedList;
//https://practice.geeksforgeeks.org/problems/rotate-a-linked-list/1

public class ReverseInGroup
{
    public class Node
    {
        Node next;

        int data;

        Node(int data)
        {
            this.data = data;

        }
    }

    Node head;

    public Node insert(Node head,int data)
    {
        Node newNode = new Node(data);
        if (head == null)
        {
            head = newNode;
            return head;
        }
        newNode.next = head;
        head = newNode;
        return head;
    }

    public Node reverseInGroup(Node head,int k)
    {
        Node current = head;
        Node next=null;
        Node privious = null;
        
        int i = 0;
        
        while(current != null && i < k) {
        	
         	next=current.next;
         	current.next=privious;
         	privious=current;
         	current=next;
          i++;
        }
        
        if(next != null) {
          head.next = reverseInGroup(next, k);
        }
        
        return privious;
    }
   
    public void print(Node node)
    {
    	if (node == null) {
    	      return;
    	    }

    	    System.out.print(node.data + " ");
    	    print(node.next);
    	    
    	  
    }
    

    public static void main(String[] args)
    {
    	Node head = null;
        ReverseInGroup a = new ReverseInGroup();
        head = a.insert(head,5);    
        head = a.insert(head,39);
        head = a.insert(head,8);
        head = a.insert(head,99);
        head = a.insert(head,12);
         a.print(head);
         System.out.println("\n");
        head=a.reverseInGroup(head,2);
       a.print(head);
    }
}
