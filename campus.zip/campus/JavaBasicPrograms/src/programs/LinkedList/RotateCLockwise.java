package programs.LinkedList;
//https://practice.geeksforgeeks.org/problems/rotate-a-linked-list/1
//https://www.youtube.com/watch?v=NC2hGWsyeLo

public class RotateCLockwise
{
    public class Node
    {
        Node next;

        int data;

        Node(int data)
        {
            this.data = data;

        }
    }

    Node head;

    public void addFront(int data)
    {
        Node newNode = new Node(data);
        if (head == null)
        {
            head = newNode;
            return;
        }
        newNode.next = head;
        head = newNode;
    }

    void rotate(int k)
    {
       //add code here
       Node newHead=head;
       Node prev=null;
       for(int i=0;i<k;i++)
       {
           prev=newHead;
           newHead=newHead.next;
       }
       
       if (newHead==null) return ;
       
       Node tail=newHead;
       while(tail.next!=null) {
    	   tail=tail.next;
       }
       
       tail.next=head;
       prev.next=null;
       head=newHead;
      // return newHead;
    }
   
    void rotateMY(int data) {
    	Node current=head;
    	/*for(int i=1;i<data && current!=null;i++) {
    		current=current.next;
    	}*/
    	int i=1;
    	while(current!=null &&i<data) {
    		current=current.next;
    		i++;
    	}
    	Node kthnode=null;
    	kthnode=current;
    	while(current.next!=null) {
    		current=current.next;
    	}
    	current.next=head;
    	head=kthnode.next;
    	kthnode.next=null;
    }
    public void print()
    {
        Node current = head;
         while (current != null)
        {
            System.out.println(current.data);
            current=current.next;
    }
    }
    
void rotateP(int pos) {
	int i=0;
	Node current =head;
	Node temp=head;
	while(i<pos-1) {
		current=current.next;
		i++;
	}
	
	Node privious=current;
	head=current.next;

	while(current.next!=null) {
		current=current.next;
	}
	current.next=temp;
	privious.next=null;

}
    public static void main(String[] args)
    {
        RotateCLockwise link = new RotateCLockwise();
        link.addFront(8);
        link.addFront(7);
        link.addFront(6);
        link.addFront(5);
        link.addFront(4);
        link.addFront(3);
        link.addFront(2);
        link.addFront(1);
        link.print();
        System.out.println("after rotate");
       // link.rotate(4);
      link.rotateMY(4);
     // link.rotateP(4);
        link.print();
    }
}
