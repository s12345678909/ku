package programs.LinkedList;

public class QueueAddLast {
	class Node{
		int data;
		Node next;
		Node (int data){
			this.data=data;
		}
	}
	Node head;
	
	void print() {
		Node currentNode=head;
		while(currentNode!=null) {
			
			System.out.println(currentNode.data+"\n");
			currentNode=currentNode.next;
			
		}
	}
	void push(int data) {
		Node newNode =new Node(data);
		if(head==null) {
			head=newNode;
			return;
		}
		Node currentNode =head;
		while(currentNode.next!=null) {
		currentNode=currentNode.next;
		}
		currentNode.next=newNode;
			
	}
	void peek() {
		System.out.println("First elemet");
		System.out.println(head.data);
		
	}
	
	void pop() {
	//	Node temp =head;
		int data= head.data;
		head=head.next;
		System.out.println("removed lement fifo "+data);
		
		
		
	}
	
	public static void main(String args[]) {
		QueueAddLast queue= new QueueAddLast();
		queue.push(1);
		queue.push(2);
		queue.push(3);
		queue.print();
		queue.peek();
		queue.pop();
		queue.print();
	}

}
