package programs.LinkedList;
//https://www.youtube.com/watch?v=Zd7TE-AjcOE&t=214s

import java.util.*;

public class RevomeDuplicates
{
    public class Node
    {
        Node next;

        int data;

        Node(int data)
        {
            this.data = data;

        }
    }

    Node head;
    public void addFront(int data)
    {
        Node newNode = new Node(data);
        if (head == null)
        {
            head = newNode;
            return;
        }
        newNode.next = head;
        head = newNode;
    }
    
    public Node addFrontH(int data,Node node)
    {
        Node newNode = new Node(data);
        if (node == null)
        {
            node = newNode;
            return node;
        }
        newNode.next = node;
        node = newNode;
        return node;
    }
    
    public void removeDuplicate()
    {
    	RevomeDuplicates rm = new RevomeDuplicates();
        Node current=head;
         HashSet<Integer> hs= new HashSet<Integer>();   
         System.out.println("cmae");
        while (current.next!=null)
        {
        	//System.out.println(current.data);
        	hs.add(current.data);
        	current=current.next;
        }
        
     /*   Iterator itr=hs.iterator();
        while(itr.hasNext()) {
        	System.out.println(itr.next());
        }*/
        for(int i:hs){
        	System.out.println("came here");
        	System.out.println(i);
        	rm.head=rm.addFrontH(i,rm.head);
        }
        Node print =rm.head;
        while(print!=null) {
        	System.out.println(print.data);
        	print=print.next;
        }
      //  print();
        
    }
    public int size() {
        if (head == null) {
            return 0;
        }
        int count = 1;
        Node current = head;
       while (current.next != null) {
            current = current.next;
            count++;
        }
        return count;
    }

    public void print()
    {
        Node current = head;

        while (current != null)
        {
            System.out.println(current.data);
            current = current.next;
        }
        System.out.println("");

    }
    
    

    public static void main(String[] args)
    {


        RevomeDuplicates link = new RevomeDuplicates();
        link.addFront(1);
        link.addFront(1);
        link.addFront(2);
        link.addFront(1);
        link.addFront(3);

    //    link.print();
        link.removeDuplicate();
       // link.print();        
    }
}
