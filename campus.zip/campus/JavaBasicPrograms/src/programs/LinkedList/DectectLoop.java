package programs.LinkedList;
//https://www.geeksforgeeks.org/detect-loop-in-a-linked-list/

public class DectectLoop {
	 Node head;
	class Node{
		int data;
		Node next;
		public Node(int d) {
			data=d;
			next=null;
		}
	}
	public void push(int data) {
		Node newNode =new Node(data);
		newNode.next=head;
		head=newNode;
	}
	//Floyd's method of Loop detection
	public void detectLoop(/*Node head*/) {
		boolean flag=false;
		Node slow ,fast;
		slow=fast=head;
		while(slow.next!=null && fast.next.next!=null) {
			slow=slow.next;
			fast=fast.next.next;
			if(slow.data==fast.data) {
				flag=true;
				break;
			}
			
			
		}
		if(flag) {
			System.out.println("Loop Detected in linked List");
			
		}else if(!flag)
			System.out.println("No loop Detcetd in Linked List");
		/**Using HasSet (Hashing)
		boolean flag=false;
		HashSet<Node> hs =new HashSet<Node>();
		
		while(head!=null) {

			
			if(hs.contains(head)) {
				flag=true;
				break;
			}
			hs.add(head);
			head=head.next;
			
			
		}
		if(flag) {
			System.out.println("Loop Detected in linked List");
			
		}else if(!flag)
			System.out.println("No loop Detcetd in Linked List");*/
	}
	
	public void removeLoop(/*Node head*/) {
		Node slow ,fast;
		slow=fast=head;
		while(slow.next!=null && fast.next.next!=null) {
			slow=slow.next;
			fast=fast.next.next;
			if(slow.data==fast.data) {
							break;
			}
			
			
		}
		if(slow==fast) {
			if(fast==head) {
				while(slow.next !=fast) {
					slow=slow.next;
				}
				slow.next=null;
			}else {
				slow=head;
				while(slow.next!=fast.next) {
					slow=slow.next;
				}
				fast.next=null;
			}
			
		}

	}
	
	  void printList() 
	    { 
	        Node temp = head; 
	        while (temp != null) { 
	            System.out.print(temp.data + " "); 
	            temp = temp.next; 
	        } 
	        System.out.println(); 
	    } 

	public static void main(String args[]) {
		DectectLoop llist = new DectectLoop();
		 llist.push(20); 
	     llist.push(4); 
	     llist.push(15); 
	     llist.push(10); 
	     llist.head.next.next.next.next =llist.head;
	     llist.detectLoop();
	     llist.removeLoop();
	     llist.printList();
	}

}
