package programs.arrays;
// Java program to find number of subarrays  
// with sum exactly equal to k.  
//https://www.youtube.com/watch?v=GY-KULykGaw
  
public class SubarrySum{ 
      
    // Function to find number of subarrays   
    // with sum exactly equal to k.  
    static void findSubarraySum(int arr[],int sum)  
    {  
    	int nsum=0;
    	for (int i=0;i<arr.length;i++) {
    		nsum =arr[i];
    		boolean flag =true;
    		if(flag) {
    		for (int j=i+1;j<arr.length;j++) {
    			nsum +=arr[j];
    			if(sum==nsum) {
        			System.out.println("subarry is between index"+i+"and "+j);
        			flag=false;
        		}
    			if(nsum>sum) {
    				nsum =nsum-arr[j];
    			}
    			
    		}
    		}
    	}
        
      
    }  
    
    static void findSubarraySumEfficient(int arr[],int sum)  
    {  
    	int nsum =arr[0];int start=0;
   	for (int i=1;i<arr.length;i++) {
    		while (nsum > sum && start < i - 1) { 
                nsum = nsum - arr[start]; 
                start++; 
            } 
    		if(nsum ==sum) {
    			System.out.println("subarry is between index"+start+"and "+(i-1));
    		}
    		nsum +=arr[i];
    		
    	}
        
      
    }  
      
     public static void main(String []args){ 
          
        int arr[] = { 15,20, 2, 4, 8, 9, 5, 10, 23 };  
        int sum = 23;  
       findSubarraySumEfficient(arr, sum); 
       findSubarraySum(arr,sum);
     } 
} 
       
//time complexity O(N^2)
