package programs.arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayMerge {
	
	 public static void main(String args[]) {
		 ArrayMerge am = new ArrayMerge();
		 am.mergeWithCollection();
		 am.bruteForceMerge();
	     
	   }
	 void mergeWithCollection() {
		 String a[] = { "A", "E", "I" };
		    String b[] = { "O", "U" };
		 List<String> list = new ArrayList<String>(Arrays.asList(a));
	      list.addAll(Arrays.asList(b));
	      Object[] c = list.toArray();
	      System.out.println(Arrays.toString(c));
	 }
	 
	 void bruteForceMerge() {
		 int[]a = {1,2,3,4};
	      int[]b = {4,16,1,2,3,22};
		 int[]c = new int[a.length+b.length];
	      int count = 0;
	      
	      for(int i = 0; i < a.length; i++) { 
	         c[i] = a[i];
	         count++;
	      } 
	      for(int j = 0; j < b.length;j++) { 
	         c[count++] = b[j];
	      } 
	      for(int i = 0;i < c.length;i++) System.out.print(c[i]+" ");
	   } 
	 
}
//Question:(See Array Matrix : https://www.geeksforgeeks.org/a-boolean-matrix-question/)

//https://www.techiedelight.com/change-elements-row-column-j-matrix-0-cell-j-value-0/  (udemy Question)
