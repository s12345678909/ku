package programs.arrays;

public class ReverseArray {
	public static void main(String args[]) {
		 String a[] = { "A", "E", "I","F"};
		 
		 for(int i=a.length-1;i>=0;i--) {
			 System.out.println(a[i]);
		 }
	/*	 for(int i =0;i<a.length-1;i++) {
			 String temp=a[i];
			 for(int j=i+1;j<a.length;j++) {
			 a[i]=a[j];
			 a[j]=temp;
			 temp=a[i];
			 }
		 }
		

		 for(int j=0;j<a.length;j++) {
			 System.out.println(a[j]);
		 }*/
	}

}
