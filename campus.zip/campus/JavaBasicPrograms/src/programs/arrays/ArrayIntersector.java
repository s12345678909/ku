package programs.arrays;
//find mode of an array https://www.tutorialspoint.com/Java-program-to-calculate-mode-in-Java
import java.util.ArrayList;

public class ArrayIntersector {
	 int[] array1 = { 1,2,4,5,6 };
     int[] array2 = { 2,3,5,7 };

public  static void main(String args[]) {

	ArrayIntersector arr = new ArrayIntersector();
	arr.intersec();
	arr.intersectElegant();
}

public void intersectElegant() {

    // array1: i length m
    // array2: i length n

    // loop through both arrays
    // if one element is less than the other ... there can be no intersection
    //  - increment the lower pointer
    //  - if elements are equal collect
    //    - then increment either of the pointers

    int i = 0; int m = array1.length;
    int j = 0; int n = array2.length;

    ArrayList<Integer> collector = new ArrayList<>();

    // O(n + m)
    while (i < m && j < n) {
        if (array1[i] < array2[j]) {
            i++;
        } else if (array2[j] < array1[i]) {
            j++;
        } else { // equal
            collector.add(array1[i]);
            i++;
        }
    }
for(Integer res:collector) {
	System.out.println(res);
}
   // return collector;
}

void intersec() {
	for (int i=0;i<array1.length;i++) {
		
		int temp=array1[i];		
		for(int j=0;j<array2.length;j++) {
			if(temp==array2[j]) {
				System.out.println("Intesected at pos"+j+"value : "+temp);
			}
		}
	}
}
}
