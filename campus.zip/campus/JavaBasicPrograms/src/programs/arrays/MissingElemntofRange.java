package programs.arrays;

public class MissingElemntofRange {
	int arr[] = { 1, 14, 11, 51, 15 };

	
	void missing() {
		boolean flag=false;
		int resarr[] = {50,51,52,53,54,55};
		for(int i=0;i<resarr.length;i++) {
			flag=false;
			int temp=resarr[i];
			for(int j=0;j<arr.length;j++) {
				if (temp==arr[j]) {
					flag=true;
				}
			}
			if (!flag) {
			System.out.println("Missing "+resarr[i]);	
			}
		}
	}
	void find(int low, int high) {
		boolean flag = false;
		int[] compareArr = build(low, high);
		for (int i = 0; i < compareArr.length; i++) {
			int temp = compareArr[i];

			for (int j = 0; j < arr.length; j++) {
				if (temp == arr[j]) {
					flag = true;
				}
			}
			if (!flag) {
				System.out.println("Missing elements are :" + compareArr[i] + " ");
			}
			flag = false;
		}

	}

	public int[] build(int low, int high) {
		int size = 0;
		int rangeFrom = low;
		int rangeTo = high;
		while (rangeFrom <= rangeTo) {
			size++;
			rangeFrom++;
		}
		System.out.println("Size of Build Array :" + size);
		int[] temp = new int[arr.length];
		for (int i = 0; i <= temp.length - 1; i++) {
			if (low <= high) {
				temp[i] = low;
				low++;
			}
		}

		return temp;

	}

	void display(int arr[]) {
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	}

	public static void main(String args[]) {
		MissingElemntofRange mis = new MissingElemntofRange();
		//mis.find(50, 55);
		mis.missing();
	}

	// without range
	/*
	 * public static void main(String[] args) {
	 * 
	 * // given input int[] input = { 1, 1, 2, 3, 5, 5, 7, 9, 9, 9 };
	 * 
	 * 
	 * // let's create another array with same length // by default all index will
	 * contain zero // default value for int variable
	 * 
	 * int[] register = new int[input.length];
	 * 
	 * // now let's iterate over given array to // mark all present numbers in our
	 * register // array
	 * 
	 * for (int i:input) { register[i] = 1; }
	 * 
	 * // now, let's print all the absentees
	 * System.out.println("missing numbers in given array");
	 * 
	 * for (int i = 1; i < register.length; i++) { if (register[i] == 0) {
	 * System.out.println(i); } } }
	 */

}
