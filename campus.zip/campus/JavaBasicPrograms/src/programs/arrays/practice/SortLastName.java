package programs.arrays.practice;
import java.util.*;

public class SortLastName {
	public class Student{  
		 
		String fname;  
		String lname; 
		int rollno;
		Student(int rollno,String fname,String lname){  
		this.rollno=rollno;  
		this.fname=fname;  
		this.lname=lname;  
		} 
	}
	
	class Name implements Comparator{
	String fname;
	String lname;

	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		Student s1= (Student)o1;
		Student s2= (Student)o2;
		  
		return s1.lname.compareTo(s2.lname);  
	}
	}
	
	class Roll implements Comparator{
	int rollno;

	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		Student s1= (Student)o1;
		Student s2= (Student)o2;
		  if(s1.rollno>s2.rollno) {
			  return 1;
		  }
		  else if(s1.rollno==s2.rollno) {
			  return 0;
		  }
		  
		  else return -1; 
	}
	}
	
	class Name1 implements Comparable<Name1>{
		int rollno;
		String Name;
	Name1(int rollno,String Name){
		this.rollno=rollno;
		this.Name=Name;
	}
		@Override
		public int compareTo(Name1 o) {
			if(o.rollno==rollno)
				return 0;
			else if (o.rollno<rollno)
				return 1;
			else
				return -1;

		}
		}
	public static void main(String args[]) {
		ArrayList<Student >al = new ArrayList<Student>();
		SortLastName ss= new SortLastName();
		SortLastName.Student n= ss.new Student(10, "Sanjiv", "Gupta");
		SortLastName.Student n1= ss.new Student(11, "Priyanka", "Sahu");
		SortLastName.Student n3= ss.new Student(12, "Rahul", "Dev");
	    al.add(n);
	    al.add(n1);
	    al.add(n3);
	    Collections.sort(al,ss.new Name());
	    Iterator itr=al.iterator();  
	    while(itr.hasNext()){  
	    Student st=(Student)itr.next();  
	    System.out.println(st.rollno+" "+st.fname+" "+st.lname);  
	    }  
	    
	    //sort by rollno
	    System.out.println("Sorting by rollno");
	    Collections.sort(al, ss.new Roll());
	    Iterator itr1=al.iterator();  
	    while(itr1.hasNext()){  
	    Student st=(Student)itr1.next();  
	    System.out.println(st.rollno+" "+st.fname+" "+st.lname);  
	    }  
	    
	    
	    //comparable
	    System.out.println("Sorting by Comprable");
	    ArrayList<Name1 >al1 = new ArrayList<Name1>();
		SortLastName.Name1 a= ss.new Name1(13, "Sanjiv");
		SortLastName.Name1 a1= ss.new Name1(10, "Priyanka");
		SortLastName.Name1 a3= ss.new Name1(9, "Rahul");
		al1.add(a);
	    al1.add(a1);
	    al1.add(a3);
		Collections.sort(al1);
		/*Iterator<Name1> itra=al1.iterator();
		while(itra.hasNext()) {
			System.out.println(itra.next());
		}*/
		for(Name1 st:al1){  
			System.out.println(st.rollno+" "+st.Name);  
			}  

	    
	}

}

