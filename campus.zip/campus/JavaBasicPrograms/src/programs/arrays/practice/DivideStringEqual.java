package programs.arrays.practice;

public class DivideStringEqual {
public static void main(String args[]) {
	
	String str="aaaabbbbcccc";
	int n=3;
	DivideStringEqual eq = new DivideStringEqual();
	eq.divide(str,n);
}

private void divide(String str,int n) {
	int temp=0;
	int len=str.length();
	if(len%n!=0) {
		System.out.println("Cant divide in equal parts");
	}
	else {
		int chars = len/n;
		String[] equalStr = new String [n];
		for(int i = 0; i < len; i = i+chars) {  
            //Dividing string in n equal part using substring()  
            String part = str.substring(i, i+chars);  //0,4 //4,8//8,12
            System.out.println("i vale :"+i+"i+chars value :"+(i+chars));
            equalStr[temp] = part;  
            temp++;  
        }  
		 System.out.println(n + " equal parts of given string are ");  
         for(int i = 0; i < equalStr.length; i++) {  
             System.out.println(equalStr[i]);  
             }  
	}
	
	// TODO Auto-generated method stub
	
}
}
