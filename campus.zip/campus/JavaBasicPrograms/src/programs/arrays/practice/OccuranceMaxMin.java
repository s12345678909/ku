package programs.arrays.practice;

import java.util.HashMap;
import java.util.Map;

public class OccuranceMaxMin {
	
	public static void main(String args[]) {
		int max=0;
		int min=2;
		String str1 = "grass is greener on the other side"; 
		String str=str1.replace(" ", "");
		System.out.println(str);
		char maxValue = '\0';
		char minValue = '\0';
		char ch[]=str.toCharArray();
		HashMap<Character, Integer> hm= new HashMap<Character, Integer>();
		for(int i=0;i<ch.length;i++) {
			
			if(hm.containsKey(ch[i])) {
				Integer count=hm.get(ch[i]);
				hm.put(ch[i], count+1);
				
			}
			else {
				hm.put(ch[i],1);
			}
		}
		for(Map.Entry m:hm.entrySet()) {
			System.out.println("key :"+m.getKey()+"count : "+m.getValue());
			
			System.out.println("Max value:"+max);
			int count=(int) m.getValue();
			if(count>max) {
				max=count;
				maxValue=(char) m.getKey();
			}
			if(count<min) {
				min=count;
				minValue=(char) m.getKey();
			}
		}
		System.out.println("MaxValue: "+maxValue +"MinValue : "+minValue);
	}

}
