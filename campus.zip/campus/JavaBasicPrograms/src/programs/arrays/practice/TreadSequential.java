package programs.arrays.practice;

 class TreadSequential extends Thread {
	static int i=1;
		Object lock = new Object();
		public void run() {
			synchronized (lock) {
				while(i<=5) {
				//for(i=1;i<=5 ;i++) {
				System.out.println(i);
				i++;
				}
				while(i>=5 &&i<=10) {
					System.out.println(i);
					i++;
				}
				//}
			}
		}
	}


