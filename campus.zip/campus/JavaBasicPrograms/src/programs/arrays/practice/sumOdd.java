package programs.arrays.practice;

public class sumOdd {
	public static void main(String args[]) {
		String s = "$Gee*k;s..fo, r'Ge^eks?";  
        removeSpecialCharacter(s); 


}

	private static void removeSpecialCharacter(String s) {
	for(int i=0;i<s.length();i++) {
		if (s.charAt(i) < 'A' || s.charAt(i) > 'Z' && 
                s.charAt(i) < 'a' || s.charAt(i) > 'z')   {
			s=s.replace(s.charAt(i), ' ');
		}
	}
	System.out.println(s.replaceAll("\\s", ""));
	}
		
	}
