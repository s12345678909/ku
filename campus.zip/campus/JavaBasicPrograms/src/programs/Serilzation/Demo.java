package programs.Serilzation;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.imageio.stream.FileImageInputStream;

public class Demo implements java.io.Serializable  {

	int id;
	String name;
	Demo(int id,String name){
		this.id=id;
		this.name=name;
	}

	public static void main(String args[]) throws IOException, ClassNotFoundException {
		Demo object = new Demo(1, "Sanjiv");
		FileOutputStream file = new FileOutputStream("C:\\Users\\sg255055\\file.ser");
		ObjectOutputStream obj = new ObjectOutputStream(file);
		obj.writeObject(object);
		obj.close(); 
        file.close();
		System.out.println("Serilized");
		Demo object1 =null;
		FileInputStream fileinp = new FileInputStream("C:\\Users\\sg255055\\file.ser");
		ObjectInputStream objinp= new ObjectInputStream(fileinp);
		object1=(Demo) objinp.readObject();
		System.out.println("Deserilised "+object1.id+" "+object1.name);
		
		
	}

}
