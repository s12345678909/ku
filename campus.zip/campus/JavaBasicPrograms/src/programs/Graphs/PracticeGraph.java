package programs.Graphs;

import java.util.LinkedList;

import javax.swing.text.html.HTMLDocument.Iterator;

public class PracticeGraph {
	LinkedList<Integer> adj[];
	public PracticeGraph(int k) {
		adj= new LinkedList[k];
		for(int i=0;i<k;i++) {
			adj[i]= new LinkedList<Integer>();
		}
		
	}
	void addedge(int v,int w) {
		adj[v].add(w);
	}
	void BFS(int v,int w) {
		String res ="";
		LinkedList<Integer> queue = new LinkedList<Integer>();
		boolean visited[]=new boolean[v];
		visited[v]=true;
		queue.add(v);
		while(!queue.isEmpty()) {
			//String s="";
			v=queue.poll();
			res =v+ " ";
			java.util.Iterator<Integer> itr= adj[v].iterator();
			while(itr.hasNext()) {
				int n = itr.next();
				if(!visited[n]) {
					visited[n]=true;
					queue.add(n);
				}
			}
			
			
		}
		
		
	}
	public static void main() {
		
	}

}
