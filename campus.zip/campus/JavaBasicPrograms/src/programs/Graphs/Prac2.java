package programs.Graphs;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Stack;

public class Prac2 {
	LinkedList<Integer> adj[];
	Prac2(int s){
		adj=new LinkedList[s];
		for(int i=0;i<s;i++) {
			adj[i]=new LinkedList<Integer>();
		}
	}
	void addEdge(int w,int v) {
		adj[w].add(v);
	}
	
	void BFS(int w,int v) {
		boolean [] visited = new boolean[v];
		LinkedList<Integer> queue = new LinkedList<Integer>();
		visited[w]=true;
		queue.add(w);
		String res="";
		while(!queue.isEmpty()) {
			w = queue.poll();
			
			res=res+ w+ " ";
			Iterator<Integer> itr= adj[w].iterator();
			while(itr.hasNext()) {
				int n = itr.next();
				if(!visited[n]) {
					visited[n]=true;
					queue.add(n);
				}
			}
		}
		System.out.println("BFS "+res);
	}
	
	void DFS(int w,int v) {
		boolean [] visited = new boolean[v];
		Stack<Integer> satck = new Stack<Integer>();
		visited[w]=true;
		satck.add(w);
		String res="";
		while(!satck.isEmpty()) {
			w = satck.pop();
			
			res=res+ w+ " ";
			Iterator<Integer> itr= adj[w].iterator();
			while(itr.hasNext()) {
				int n = itr.next();
				if(!visited[n]) {
					visited[n]=true;
					satck.add(n);
				}
			}
		}
		System.out.println("DFS "+res);
	}
public static void main(String args[]) {
	Prac2 g= new Prac2(8);
	g.addEdge(0, 1);
    g.addEdge(1, 0);
    g.addEdge(1, 4);
    g.addEdge(4, 1);
    g.addEdge(4, 6);
    g.addEdge(6, 4);
    g.addEdge(6, 0);
    g.addEdge(0, 6);
    g.addEdge(1, 5);
    g.addEdge(5, 1);
    g.addEdge(5, 3);
    g.addEdge(3, 5);
    g.addEdge(3, 0);
    g.addEdge(0, 3);
    g.addEdge(5, 2);
    g.addEdge(2, 5);
    g.addEdge(2, 7);
    g.addEdge(7, 2);
    
    g.BFS(0, 8);
    g.DFS(0, 8);
	
}
}
