package programs.Graphs;
//consecutive ones in N digit number DP problem
public class ones {
	
	int countBinNums(int n) {
		   int endWithZero[]= new int[n];
		int endWithOne[]= new int[n];
		   endWithZero[0] = endWithOne[0] = 1;

		   for (int i = 1; i < n; i++) {
		      endWithZero[i] = endWithZero[i-1] + endWithOne[i-1];
		      endWithOne[i] = endWithZero[i-1];
		   }
		   return endWithZero[n-1] + endWithOne[n-1];
		}

		public static void  main(String args[]) {
			ones o = new ones();
		   int n=5;
		   int count=o.countBinNums(n);
		   System.out.println(count);
		}

}


/*h-Index

public int hIndex(int[] citations) {
Arrays.sort(citations);

int result = 0;
for(int i=citations.length-1; i>=0; i--){
    int cnt = citations.length-i;
    if(citations[i]>=cnt){
        result = cnt;
    }else{
        break;
    }
}

return result;
}*/