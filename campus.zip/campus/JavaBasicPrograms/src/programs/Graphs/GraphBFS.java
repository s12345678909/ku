package programs.Graphs;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

import com.sun.xml.internal.bind.v2.runtime.reflect.ListIterator;

public class GraphBFS {
	private LinkedList<Integer> adj[];
	
	public GraphBFS(int v) {
		adj=new LinkedList[v];
		for(int i=0;i<v;i++) {
			adj[i]=new LinkedList<Integer>();
		}
	}
	void addEdge(int v,int w) {
		adj[v].add(w);
	}
	
	void BFS(int s,int v) {
		String res="";
		boolean  visited[] = new boolean[v];
		
		LinkedList<Integer> queue = new LinkedList<Integer>();
		//Queue<Integer> queue = new LinkedList<Integer>();
		//add the first element to queue
		visited[s]=true;
		System.out.println("Adding To Queue :"+s);
		queue.add(s);
		
		//now remove first element and check the neighoubour of the first element and mark visited
		while(!queue.isEmpty()) {
			s= queue.poll();
			System.out.println("Dequeued :"+s);
			res +=s+ " ";
			
			Iterator<Integer> itr =adj[s].iterator();
			while(itr.hasNext()) {
				int n= itr.next();
				if(!visited[n]) {
					visited[n] = true;
					System.out.println("Adding To Queue :"+n);
					queue.add(n);
				}
			}
			
		}
		System.out.println("BFS PATH : "+res);
	}
	void DFS(int s,int v ) {
		String res="";
		boolean visited[]= new boolean[v];
		Stack<Integer> stack= new Stack<Integer>();
		visited[s]=true;
		stack.push(s);
		while(!stack.empty()) {
			Integer current=stack.pop();
			res +=current.toString()+" ";
			
			Iterator<Integer> itr=adj[current].iterator();
			while(itr.hasNext()) {
				int n=itr.next();
				if(!visited[n]) {
					visited[n]=true;
					stack.add(n);
				}
			}
		}
		System.out.println("DFS PATH :"+res);
				
	}
		
	
	public static void main(String args[]) {
		GraphBFS g = new GraphBFS(8);
		g.addEdge(0, 1);
        g.addEdge(1, 0);
        g.addEdge(1, 4);
        g.addEdge(4, 1);
        g.addEdge(4, 6);
        g.addEdge(6, 4);
        g.addEdge(6, 0);
        g.addEdge(0, 6);
        g.addEdge(1, 5);
        g.addEdge(5, 1);
        g.addEdge(5, 3);
        g.addEdge(3, 5);
        g.addEdge(3, 0);
        g.addEdge(0, 3);
        g.addEdge(5, 2);
        g.addEdge(2, 5);
        g.addEdge(2, 7);
        g.addEdge(7, 2);
        
        g.BFS(0, 8);
        g.DFS(0, 8);
		
	}

}
