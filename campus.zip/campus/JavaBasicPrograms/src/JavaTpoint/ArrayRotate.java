package JavaTpoint;

public class ArrayRotate {
	int array[] = { 1, 2, 3, 4, 5 };

	//copy up
	void leftrotate(int index) {
		for(int j=0;j<index;j++) {
		int pos0 = array[0];
		for (int i = 0; i < array.length - 1; i++) {
			array[i] = array[i + 1];
		}
		array[array.length - 1] = pos0;
		}
		
		display();
	}
	//copy down
	void rightrotate(int n) {
		//Rotate the given array by n times toward right    
        for(int i = 0; i < n; i++){    
   
            //Stores the last element of array    
           int last = array[array.length-1];    
             for(int j = array.length-1; j > 0; j--){    
                //Shift element of array by one    
                array[j] = array[j-1];    
            }    
            //Last element of array will be added to the start of array.    
            array[0] = last;    
        }    
		display();
	}
	void even() {
	
		for (int i = 1; i < array.length - 1; i++) {

			System.out.println("Even: "+array[i]);
			i++;
		}
		for (int i = 0; i < array.length - 1; i++) {

			System.out.println("Odd: "+array[i]);
			i++;
		}
		
	}
	void thirdlargest() {
		int array[]={1,2,5,6,3,2};

		for(int i=0;i<array.length;i++) {
			for(int j=i+1;j<array.length;j++) {
				if (array[i]>array[j]) {
					int temp= array[i];
					array[i]=array[j];
					array[j]=temp;
				}
				
			}
		}
		System.out.println("3rd largest is : "+array[array.length-3]);
	}
	void removeDuplicate() {
		//for unsorted array
		//https://www.geeksforgeeks.org/remove-duplicates-from-unsorted-array-using-map-data-structure/
		//sorted array
		int arr[] = {10,20,20,30,30,40,50};
		int [] temp = new int[arr.length];
		int j=0;
		for(int i=0;i<arr.length-1;i++) {
			if(arr[i]!=arr[i+1]) {
				temp[j]=arr[i];
				j++;
			}
		}
		//temp[j++] = arr[arr.length-1];   
		for(int k=0;k<j;k++) {
			arr[k]=temp[k];
		}
		for (int i = 0; i <j; i++) {
			System.out.println(arr[i]);
		}
		
	}

	void display() {
		for (int i = 0; i < array.length; i++) {
			System.out.println(array[i]);
		}
	}

	public static void main(String args[]) {
		ArrayRotate rot = new ArrayRotate();
		System.out.println("Left Rotate");
	    rot.leftrotate(2); //revise
	//	rot.even();
	// rot.rightrotate(3);  //revise
		//rot.thirdlargest();
		//rot.removeDuplicate();  //v.v.imp revise

	}
}
