package JavaTpoint;

public class ImpStringSubset {
	void subSet() {
		String str = "ABC";
		int temp=0;
		int len = str.length();
		String arr[]= new String [len*(len+1)/2];  //importatnt n(n+1)/2
		for(int i=0;i<len;i++) {
			for(int j=i;j<len;j++) {
				arr[temp]=str.substring(i,j+1); //important
				temp++;
			}
		}
		for(int k=0;k<arr.length;k++) {
			System.out.println(arr[k]);
		}
	}
	public static void main(String args[]) {
		ImpStringSubset sub = new ImpStringSubset();
		sub.subSet();
		
	}

}


