package JavaTpoint;

public class StringPermutation {

	void permutaion(String str) {
		StringPermutation per = new StringPermutation();
		//per.computeperm("", str);
		per.com("",str);

	}

	private void computeperm(String perm, String str) {
		System.out.println(perm);
		for (int i = 0; i < str.length(); i++) {

			computeperm(perm + str.charAt(i) ,  str.substring(0, i) + str.substring(i + 1, str.length()));
			
			//computeperm(perm + str.charAt(i),str.substring(i + 1, str.length()));  //for string subset use this

		}

	}
	
	void com(String res,String str) {
		//String res="";
		System.out.println(res);
		for(int i=0;i<str.length();i++) {
		com(res+str.charAt(i),str.substring(0,i)+str.substring(i+1,str.length()));
		
		}
		
		
	}

	public static void main(String args[]) {
		StringPermutation per = new StringPermutation();
		String str = "ABC";
		System.out.println(str.substring(0, str.length()));
		per.permutaion(str);

	}

}
