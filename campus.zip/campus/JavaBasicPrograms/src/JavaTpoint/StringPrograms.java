package JavaTpoint;

import com.sun.org.apache.bcel.internal.generic.ISUB;

public class StringPrograms {

	void divide(int n) {
		String str = "aaaabbbbcccc";
		int len = str.length();
		if (len % n != 0) {
			System.out.println("Cant divide the str in equal parts");
		}
		int firstpart = len / 3;
		String[] split = str.split("");
		int i = 0;
		for (i = 0; i < firstpart; i++) {
			System.out.print(split[i]);
		}
		System.out.println("\n");
		int m = 0;
		for (m = i; m < split.length - firstpart; m++) {
			System.out.print(split[m]);
		}
		System.out.println("\n");
		for (int nn = m; nn < split.length; nn++) {
			System.out.print(split[nn]);
		}
	}

	void caseConvert() {
		System.out.println("\n");
		String str = "Great Power";
		StringBuffer res = new StringBuffer();
		char arr[] = str.toCharArray();
		
		for (int i = 0; i < arr.length; i++) {
			//System.out.println(str.charAt(i));
			if (Character.isUpperCase(arr[i])) {
				res.append(Character.toLowerCase(arr[i]));
			} else if (Character.isLowerCase(arr[i])) {
				res.append(Character.toUpperCase(arr[i]));
			} else
				res.append(arr[i]);
		}
		System.out.println(res.toString());
	}

	void rotation() {
		
		String str1 = "abcde", str2 = "deabc";

		if (str1.length() != str2.length()) {
			System.out.println("Second string is not a rotation of first string");
		} else {
			// Concatenate str1 with str1 and store it in str1
			str1 = str1.concat(str1);
			// Check whether str2 is present in str1
			if (str1.indexOf(str2) != -1)
				System.out.println("Second string is a rotation of first string");
			else
				System.out.println("Second string is not a rotation of first string");
		}
	}
	void swapString() {
		
		 String str1 = "Good ", str2 = "morning ";    
         System.out.println("Strings before swapping: " + str1 + " " + str2);    
        
        //Concatenate both the string str1 and str2 and store it in str1   
        str1 = str1 + str2;    
        //Extract str2 from updated str1    
        str2 = str1.substring(0, (str1.length() - str2.length()));    
        //Extract str1 from updated str1    
        str1 = str1.substring(str2.length());    
            
        System.out.println("Strings after swapping: " + str1 + " " + str2);    
    
	}

	public static void main(String args[]) {
		StringPrograms s1 = new StringPrograms();
		s1.divide(3);
		s1.caseConvert(); // revise
		s1.rotation(); // revise
		s1.swapString();

	}
}
