package JavaTpoint;

//TODO SELF
//https://www.javatpoint.com/java-program-to-find-maximum-and-minimum-occurring-character-in-a-string
//https://www.geeksforgeeks.org/print-longest-palindrome-word-sentence/

public class StringPatternPrint {
	public static void main(String args[]) {
		//todo https://www.javatpoint.com/how-to-print-pattern-in-java


		
	}

}
