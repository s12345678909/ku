package JavaTpoint;
//https://www.javatpoint.com/java-program-to-find-the-duplicate-words-in-a-string
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

//Java program to find the duplicate words in a string
public class CountDuplicateWords {
	
	void find(String str) {
		HashMap<String ,Integer> map = new HashMap<String, Integer>();
		String temp=str.toLowerCase();
		String [] words = temp.split("\\s");
		for(int i=0;i<words.length;i++) {
			
			if(map.containsKey(words[i])) {
				Integer count =map.get(words[i]);
				map.put(words[i], count+1);
			}else {
				map.put(words[i], 1);
			}
		}
		for(Map.Entry m : map.entrySet()) {
		//for(Entry<String, Integer> m:map.entrySet()) {
            int count =(int) m.getValue();
			if(count>1) {
				System.out.println(m.getKey()+"count:"+m.getValue());
			}
		}
	}
	
	public static void main(String args[]) {
		String string = "Big black bug bit a big black dog on his big black nose black";   
		CountDuplicateWords count = new CountDuplicateWords();
		count.find(string);
	}
	

}
