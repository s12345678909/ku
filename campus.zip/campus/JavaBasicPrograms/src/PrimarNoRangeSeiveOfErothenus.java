//
//public class PrimarNoRangeSeiveOfErothenus {
//	
//	void prime(int num) {
//		int ct=0,n=0,i=1,j=1;  
//		while(n<num)  
//		{  
//			j=1;  
//			ct=0;  
//		while(j<=i)  
//		{  
//			if(i%j==0)  
//				ct++;  
//			j++;   
//		}  
//		if(ct==2)  
//		{  
//			System.out.printf("%d ",i);  
//			n++;  
//		}  
//		i++;  
//		}      
//	}
//	public static void main(String[] args)   
//    {  
//		PrimarNoRangeSeiveOfErothenus pm = new PrimarNoRangeSeiveOfErothenus();
//		pm.prime(25);
//    }
//
//}
