
public class ArrayMatrix {

	public void sub() {
		int[][] arr1 = { { 2, 2, 2, 2 }, { 2, 2, 2, 2 }, { 2, 2, 2, 2 }, { 2, 2, 2, 2 } };

		int arr2 [][]= { { 1, 1, 1, 1 }, { 1, 1, 1, 1 }, { 1, 1, 1, 1 }, { 1, 1, 1, 1 } };
		int row = arr1.length;
		int col = arr1[0].length;

		int[][] temp = new int[row][col];

		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				temp[i][j] = arr1[i][j] - arr2[i][j];
			}
		}

		for (int k = 0; k < row; k++) {
			for (int l = 0; l < col; l++) {
				System.out.print(temp[k][l] + " ");
			}
			System.out.println();
		}
	}

	public static void main(String args[]) {

		ArrayMatrix mat = new ArrayMatrix();
		mat.sub();
	}

}
