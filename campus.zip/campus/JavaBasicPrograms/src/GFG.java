// Java program to find four elements a, b, c 
// and d in array such that ab = cd 
import java.io.*; 
import java.util.*; 

class GFG { 
	
	public static class pair { 
		
		int first,second; 
		
		pair(int f, int s) 
		{ 
			first = f; 
			second = s; 
		} 
	}; 
	
	// Function to find out four elements 
	// in array whose product is ab = cd 
	public static void findPairs(int arr[], int n) 
	{ 
		
		boolean found = false; 
		HashMap<Integer, pair> hp = 
					new HashMap<Integer, pair>(); 
		
		for(int i = 0; i < n; i++) 
		{ 
			for(int j = i + 1; j < n; j++) 
			{ 
				

				int sum = arr[i] + arr[j]; 
				
				if(!hp.containsKey(sum)) 
					hp.put(sum, new pair(i,j)); 

				else
				{ 
					pair p = hp.get(sum); 
					System.out.println("("+arr[p.first] 
							+ "," + arr[p.second] 
							+ ") " + "equals" + " (" + 
							arr[i] + "," + arr[j]+")"); 
					found = true; 
				} 
			} 
		} 
		
		if(found == false) 
		System.out.println("No pairs Found"); 
	} 
	

	public static void main (String[] args) 
	{ 
		int arr[] = {1, 2, 3, 4, 5}; 
		int n = arr.length; 
		findPairs(arr, n);	 
	} 
} 

