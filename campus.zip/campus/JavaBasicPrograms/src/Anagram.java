import java.util.HashMap;

//https://www.javatpoint.com/java-program-to-check-whether-two-strings-are-anagram-or-not

public class Anagram {
	
	void anagram(String str1, String str2) {
		//char[] ch = str.toCharArray();
		 // Map 1
        HashMap<String, Integer> map1 = map(str1);

        // Map 2
        HashMap<String, Integer> map2 = map(str2);
        
        System.out.println(map1.equals(map2));
      // System.out.println( map1.containsValue(map2));
		
	}
	 private HashMap<String, Integer> map(String text) {
	        HashMap<String, Integer> map = new HashMap<String, Integer>();
	        char[] ch= text.toCharArray();
	        for(int i=0;i<ch.length;i++) {
	        	String letter = String.valueOf(ch[i]);
	        	// if we already have, just increment
	            if (map.containsKey(letter)) {
	                Integer currentCount = map.get(letter);
	                map.put(letter, currentCount + 1);
	            } else { // else add
	                map.put(letter, 1);
	            }
	        }

	        return map;
	       
	 }

public static void main(String args[]) {
	String str1 ="night";
	String str2 ="thing";
	Anagram a= new Anagram();
	a.anagram(str1,str2);
	
}
}
