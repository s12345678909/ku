/*logic
 * 153 = (1*1*1)+(5*5*5)+(3*3*3)  
where:  
(1*1*1)=1  
(5*5*5)=125  
(3*3*3)=27  
So:  
1+125+27=153  
 */
public class ArmstrongNo {
	public static void main(String args[]) {
		int n =153;
		int r;
		int sum = 0;
		int temp =n;
		while(n>0) {
			r =n%10;
			n=n/10;
			sum =sum +r*r*r;
		}
		System.out.println("sum :"+sum);
		if(temp==sum) {
			System.out.println("No is ArmStrong");
		}else
			System.out.println("No is Not Armstrong");
	}

}
