
public class PrimeNo {
	public static void main(String args[]) {
		int n=2;
		 boolean flag = true ;
		
		if(n==1 || n==0) {
			
			System.out.println("No is not prime");
		}else
			for(int i=2;i<=n/2;i++) {
				if (n%i==0) {
					flag=false;
				}
			}
		if(flag) {
			System.out.println("prime no");
		}else if (!flag) {
			System.out.println("Not prime no");
		}
		int range=100;
		PrimeNo.prime(range);
	}

	
	static void prime(int n) {
		StringBuffer str = new StringBuffer();
		for (int j=2;j<n;j++) {
		//int n=3;
		 boolean flag = true ;
		
		if(j==1 || j==0) {
			
			System.out.println("No is not prime");
		}else
			for(int i=2;i<=j/2;i++) {
				if (j%i==0) {
					flag=false;
				}
			}
		if(flag) {
			//System.out.println("prime no "+j);
			str.append(j);
			str.append(" ");
		}
	}
		System.out.println(str);
	}
	//}
}
