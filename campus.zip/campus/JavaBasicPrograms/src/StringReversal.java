
public class StringReversal {
	
	void reverse(String str) {
		String [] chars = str.split("");
		for(int i=0;i<chars.length-1;i++) {
			for(int k=i+1;k<chars.length;k++) {
			String  temp=chars[k];
			chars[k]=chars[i];
			chars[i]=temp;
			}
		}
		for (int j=0;j<chars.length;j++) {
			System.out.println(chars[j]);
		}
	}

	void reverseOptimum(String str) {
		char[] ch=str.toCharArray();
		int left=ch.length;
		int right=ch.length-1;
		
		for(left=0;left<right;left++,right--) {
			char temp=ch[right];
			ch[right]=ch[left];
			ch[left]=temp;
		}
		System.out.println(String.valueOf(ch));
	}

	void newMethod(String string) {
		String reversedStr = "";    
        
        //Iterate through the string from last and add each character to variable reversedStr   
        for(int i = string.length()-1; i >= 0; i--){    
            reversedStr = reversedStr + string.charAt(i);    
        }    
            
        System.out.println("Original string: " + string);    
        //Displays the reverse of given string    
        System.out.println("Reverse of given string: " + reversedStr);    
    }    
	
	void practice(String str) {
		String rev ="";
		char [] arr=str.toCharArray();
		for(int i=0;i<arr.length;i++) {
		 
			for(int j=i+1;j<arr.length;j++) {
				char temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
				//temp=arr[i];
			}
		}
		for (int j=0;j<arr.length;j++) {
			rev +=arr[j];
			//System.out.println(arr[j]);
		}
		System.out.println("Reverse String :"+rev);
	}
	public static void main(String args[]) {
		StringReversal s = new StringReversal();
		String str="abcdfg";
		//s.reverse(str);
		//s.reverseOptimum(str);
		//s.newMethod(str);
		s.practice(str);
	}

}
