package program.interviewasked;


import java.util.HashSet;
import java.util.Iterator;

public class test
{
   int arr[]={0,0,0,1,2,3,45,23};
    //shift the zero at the end
   
   public void shiftEnd(){
       int temp[]= new int [arr.length];
       int count=0;
       int j = 0;
       HashSet<Integer> hs= new HashSet<Integer>();
       for(int i=0;i<arr.length;i++) {
           if(arr[i]==0) {
               count++;
           }
           else if(arr[i]!=0) {
               temp[j]=arr[i];
               j++;
              // hs.add(arr[i]);
           }
           }
       
       
       /*for(Integer i:hs) {
           temp[i]=hs;
       }*/
     /*  Iterator<Integer> itr = hs.iterator();
       int j = 0;
       while(itr.hasNext()) {
          int n =itr.next();
           temp[j]=n;
           j++;
           System.out.println(itr.next());
       }
       System.out.println("COunt of 0 : "+count);*/
       display(temp);
       
   }
    public void display(int array[]){
        for(int i=0;i<=array.length-1;i++) {
            System.out.print(array[i]+" ");
        }
    }
    public static void main(String args[]) {
       test t= new test();
        t.shiftEnd();
        
    }
}
//find the nth max slary

