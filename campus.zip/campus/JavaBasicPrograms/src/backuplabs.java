import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class backuplabs {
	
	private static void writeUsingFiles(String data) {
        try {
        	String home = System.getProperty("user.home");
        	String path=home+"\\groupdrop1000.txt";
        	System.out.println(path);
            Files.write(Paths.get(path), data.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Done");
	}
	public static void main(String args[]) {
		String data1 = "";
		for(int i=1;i<2;i++) {
		String data = "LoadTest"+i;
		String str="curl -k --insecure -X POST \"https://sandbox-qa.labs.teradata.com/api/lab/engines/4/containers/2/groups\" -H  \"accept: application/json\" -H  \"$TOKEN\" -H  \"Content-Type: application/json\" -d \"{\\\"request\\\":{\\\"comment\\\":\\\"Creating group with service defaults.\\\"},\\\"group\\\":{\\\"group_parent\\\":\\\"LoadTest\\\",\\\"group_name\\\":\\\""+data+"\\\",\\\"group_size\\\":10}}\"";
		data1+=str+" && ";
		}
		writeUsingFiles(data1);
		}
//	public static void main(String args[]) {
//		String data1 = "";
//		for(int i=1;i<=1000;i++) {
//			//String data = args[0]+i;
//		String data = "LoadTest"+i;
//		String str="Drop database "+data;
//		data1+=str+";";
//		}
//		writeUsingFiles(data1);
//		}
}

