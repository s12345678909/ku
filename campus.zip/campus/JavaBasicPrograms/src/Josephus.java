//https://www.youtube.com/watch?v=nWJaPNwzwrw
public class Josephus {
	
	void winner(int no,int steps) {
		int start=1;
		for(int i=1;i<=no;i++) {
			//start=(start+steps-1)%i+1;  or
			start =(start+steps)%i;
		}
		System.out.println(start+1);
	}
public static void main(String args[]) {
	Josephus js= new Josephus();
	js.winner(10,2);
	js.winner(7,4);
}
}
