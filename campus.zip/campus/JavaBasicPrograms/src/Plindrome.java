/**logic
 *  A palindrome number is a number that is same after reverse.
 *   For example 545, 151, 34543, 343, 171, 48984 are the palindrome numbers
 * @author sg255055
 *
 */
public class Plindrome {
	public static void main(String args[]) {
		int n=123;
		int r;
		int s = 0;
		int temp =n;
		while(n>0) {
			r=n%10; //gives remainder i.e 3
			n=n/10;  //updates the value of n from 123 to 12
			s =(s*10)+r;  //store the revrse no in temp i.e 3  (lastly 321)
			System.out.println(s);
		}
		if ( temp ==s) {
			System.out.println("NO is plindrome");
		}else
			System.out.println("no is not palindrome");
		
	}

}
