
public class IntegerReverse {
	void reverseInteger(int num) {
		int s=0;
		int r;
		while(num>0) {
			r= num%10;
			num =num/10;
			s=(s*10)+r;
			
		}
		System.out.println(s);
		
	}
	public static void main(String args[]) {
		IntegerReverse s = new IntegerReverse();
		int str=123456;
		s.reverseInteger(str);
	}

}
