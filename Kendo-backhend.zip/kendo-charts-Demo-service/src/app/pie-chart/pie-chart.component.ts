import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.css']
})
export class PieChartComponent implements OnInit {

  constructor() {

   }

  ngOnInit(): void {
  }
  public autofit = true;
  public data: any[] = [{
    "kind": "Covered", "share": 4.30+"%"
  }, {
    "kind": "Not Covered", "share": 95.07+"%"
  }];

  public labelContent(e: any): string {
    return e.value;
  }
}