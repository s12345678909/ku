import { SimpleChanges } from '@angular/core';
import { Component, OnInit,Input, OnChanges } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.css']
})
export class BarChartComponent implements OnInit,OnChanges {

  constructor(private dataService: DataService) { }
  //public data1: any[];
  @Input() data: any[];
  ngOnInit(): void {
    this.dataService.retrieveAllBarData().subscribe((databar: any[])=>{
      // console.log(data);
       //console.log("data",this.products)
       this.data = databar;
     //  console.log(this.data)
     
     })
  }
  /*public data: any[] = [{
    "kind": "Critical","value":0
  }, {
    "kind": "Blocker","value":0
  },
  {
    "kind": "Major", "value": 33
  }];*/

  public labelContent(e: any): string {
    return e.kind;
  }

ngOnChanges(changes: SimpleChanges) {
  console.log("came here")
console.log("chile message",this.data)
  }
}

