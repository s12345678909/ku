import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private REST_API_SERVER = "http://localhost:8080"

  constructor(private httpClient: HttpClient) { }
  retrieveAllTblData() {
    return this.httpClient.get(this.REST_API_SERVER+'/grid');
   //console.log("Execute Hello World Bean Service")
 }
 retrieveAllBarData() {
  return this.httpClient.get(this.REST_API_SERVER+'/bar/7');
 //console.log("Execute Hello World Bean Service")
}
retrieveAllBarDatayears() {
  return this.httpClient.get(this.REST_API_SERVER+'/bar/6');
 //console.log("Execute Hello World Bean Service")
}
//new code
public parentMessage: any[]= [{
  "kind": "Critical","value":0
}, {
  "kind": "Blocker","value":0
},
{
  "kind": "Major", "value": 30
}];
private messageSource = new BehaviorSubject(this.parentMessage);
  currentMessage = this.messageSource.asObservable();

  changeMessage(parentMessage: any[]) {
    console.log("came here",parentMessage)
    this.messageSource.next(parentMessage)
  }
}

