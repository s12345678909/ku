import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ChartsModule } from '@progress/kendo-angular-charts';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import 'hammerjs';
import { DomainQualityComponent } from './domain-quality/domain-quality.component';
import { ComponentQualityComponent } from './component-quality/component-quality.component';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { HomeComponent } from './home/home.component';
import { LabelModule } from '@progress/kendo-angular-label';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { PieChartComponent } from './pie-chart/pie-chart.component';
import { BarChartComponent } from './bar-chart/bar-chart.component';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list'
import { MatButtonModule } from '@angular/material/button';
import { HeaderNavComponent } from './header-nav/header-nav.component';
import { AreaChartComponent } from './area-chart/area-chart.component'
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';

import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { IconsModule } from '@progress/kendo-angular-icons';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { GridModule, PDFModule, ExcelModule } from '@progress/kendo-angular-grid';
import { TableGridComponent } from './table-grid/table-grid.component';
import { RatingComponent } from './table-grid/rating.component';
import { IndicatorsModule } from '@progress/kendo-angular-indicators';
import { ExpandableTableComponent } from './expandable-table/expandable-table.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


@NgModule({
  declarations: [
    AppComponent,
    DomainQualityComponent,
    ComponentQualityComponent,
    HomeComponent,
    PieChartComponent,
    BarChartComponent,
    HeaderNavComponent,
    AreaChartComponent,
    TableGridComponent,
    RatingComponent,
    ExpandableTableComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ChartsModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatIconModule,
    InputsModule,
    LabelModule,
    LayoutModule,
    MatSidenavModule,
    MatListModule,
    MatButtonModule,
    MatIconModule,
    DropDownsModule,
    ButtonsModule,
    IconsModule,
    PDFModule,
    ExcelModule,
    GridModule,
    IndicatorsModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
