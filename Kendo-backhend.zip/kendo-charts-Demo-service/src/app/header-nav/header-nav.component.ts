
import { Component, ViewChild ,OnInit} from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { DataService } from '../data.service';

@Component({
  selector: 'app-header-nav',
  templateUrl: './header-nav.component.html',
  styleUrls: ['./header-nav.component.css']
})
export class HeaderNavComponent implements OnInit {
  selectedDay: String;
  parentMessage: any[];
  constructor(private dataService: DataService) { }

  ngOnInit(): void {
  }
  title = 'sidennav';
  @ViewChild('sidenav')
  sidenav!: MatSidenav;
  isExpanded = true;
  showSubmenu: boolean = false;
  isShowing = false;
  showSubSubMenu: boolean = false;

  mouseenter() {
    if (!this.isExpanded) {
      this.isShowing = true;
    }
  }

  mouseleave() {
    if (!this.isExpanded) {
      this.isShowing = false;
    }
    
  }
  public listItems: Array<string> = ['Last 3 Months', 'Last 6 Months', 'Last 12 Months'];
  public selectedValue = 'Last 12 Months';
  //s=this.showVale()
  //selectedDay: string = '';
;
//public data: any[];

handleProductChange(value){
    this.selectedDay = value;
    console.log(this.selectedDay)
    this.dataService.retrieveAllBarDatayears().subscribe((databar: any[])=>{
      // console.log(data);
       //console.log("data",this.products)
       this.parentMessage = databar
       console.log("nav header",this.parentMessage)
     })
     // console.log("value",this.selectedValue,event.target.value);
    }
    
}
