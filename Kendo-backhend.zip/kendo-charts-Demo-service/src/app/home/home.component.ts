import { Component, OnInit } from '@angular/core';
import { TabAlignment } from '@progress/kendo-angular-layout';//wrenchIcon
import { filesErrorIcon } from '@progress/kendo-svg-icons';
import { gearsIcon } from '@progress/kendo-svg-icons';
import { alignCenterIcon } from '@progress/kendo-svg-icons';
import { fileTxtIcon } from '@progress/kendo-svg-icons';
import { trackChangesAcceptAllIcon } from '@progress/kendo-svg-icons';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  public alignment: TabAlignment = 'start';

  public icons = { wrenchicon: filesErrorIcon ,gearsicon:gearsIcon,chevronLefticon:alignCenterIcon,fileTxticon:fileTxtIcon,trackChangesAcceptAllicon:trackChangesAcceptAllIcon};
}
