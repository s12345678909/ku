import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {TableGridComponent} from './table-grid/table-grid.component'
import {HeaderNavComponent} from './header-nav/header-nav.component'
import {ExpandableTableComponent} from './expandable-table/expandable-table.component'
const routes: Routes = [  
  { path: '', component: HeaderNavComponent  },//canActivate, RouteGuardService//gridtable
  { path: 'gridtable', component: TableGridComponent  },//canActivate, RouteGuardService//gridtable//
  { path: 'table-expandable', component: ExpandableTableComponent  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
