package com.javatpoint;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class ProductController 
{
@Autowired
private IProductService productService;
//mapping the getProduct() method to /product
@GetMapping(value = "/product")
public List<Product> getProduct() 
{
//finds all the products
List<Product> products = productService.findAll();
//returns the product list
return products;
}
@GetMapping(value = "/grid")
public List<TableGrid> getTableGrid() 
{
//finds all the products
List<TableGrid> tableGrid = productService.findAllTbl();
//returns the product list
return tableGrid;
}
/*@GetMapping(value = "/bar")
public List<BarChart> getbarChart() 
{
//finds all the products
List<BarChart> barChart = productService.retriveAll();
//returns the product list
return barChart;
}*/
@GetMapping(value = "/bar/{id}")
public List<BarChart> getbarChartdate(@PathVariable("id") int id) 
{
//finds all the products
List<BarChart> barChart = productService.retriveAll(id);
//returns the product list

return barChart;
}
}
