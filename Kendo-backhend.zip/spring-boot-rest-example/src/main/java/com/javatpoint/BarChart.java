package com.javatpoint;

public class BarChart {
	private String kind;
	private int value;
	
	public BarChart(String kind,int value) {
		this.kind=kind;
		this.value=value;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}

}
