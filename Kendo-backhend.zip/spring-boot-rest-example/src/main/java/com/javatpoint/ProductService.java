package com.javatpoint;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class ProductService implements IProductService {
	@Override
	public List<Product> findAll() {
//creating an object of ArrayList
		ArrayList<Product> products = new ArrayList<Product>();
//adding products to the List
		products.add(new Product(100, "Mobile", "CLK98123", 9000.00, 6));
		products.add(new Product(101, "Smart TV", "LGST09167", 60000.00, 3));
		products.add(new Product(102, "Washing Machine", "38753BK9", 9000.00, 7));
		products.add(new Product(103, "Laptop", "LHP29OCP", 24000.00, 1));
		products.add(new Product(104, "Air Conditioner", "ACLG66721", 30000.00, 5));
		products.add(new Product(105, "Refrigerator ", "12WP9087", 10000.00, 4));
//returns a list of product
		return products;
	}

	@Override
	public List<TableGrid> findAllTbl() {
		// TODO Auto-generated method stub
		ArrayList<TableGrid> tblGrid = new ArrayList<TableGrid>();
		tblGrid.add(new TableGrid("19d18d40-0e64-4837-9420-92130a0ed253", "Shelden Greyes", "Operator", "GB", true, 5,
				40, 12253, "(343) 6656271", "2 Waxwing Point", 2, "M"));
		tblGrid.add(new TableGrid("bebdc6eb-9179-484a-917d-2e16a23bfdfe", "Megen Cody", "Operator", "BR", true, 1, 66,
				96183, "(178) 2336256", "4082 Stephen Court", 6, "F"));
		tblGrid.add(new TableGrid("38b08b88-e482-46fc-8976-83590c02ec23", "Clevey Thursfield", "VP Quality Control",
				"BR", true, 2, 58, 54936, "(277) 7415010", "1563 Glacier Hill Parkway", 5, "M"));
		tblGrid.add(new TableGrid("2aac53f8-b72d-4629-9082-6d8239a8fecf", "Ruthi Baldini", "Data Coordiator", "BR",
				true, 3, 37, 46572, "(766) 5691615", "6 Laurel Avenue", 8, "F"));
		tblGrid.add(new TableGrid("1aa789e5-de01-406e-a2ee-cc5ce20f7e34", "Annecorinne Morter", "Professor", "FR",
				false, 2, 35, 37198, "(807) 2524830", "106 Green Street", 3, "F"));
		tblGrid.add(new TableGrid("d2ff1b02-3808-44aa-9056-3b5df34bf865", "Gracia Punyer", "Assistant Manager", "ES",
				true, 4, 64, 84752, "(515) 9749536", "69 Brentwood Alley", 2, "F"));
		tblGrid.add(new TableGrid("26b2b760-27e8-47a6-81c2-07870d1b2b30", "Duky Hurring", "Account Executive", "BR",
				false, 3, 61, -1266, "(897) 7202034", "39 Morning Circle", 3, "M"));
		tblGrid.add(new TableGrid("91c6b652-4206-4a0c-bac6-dc21283a72d7", "Briana Shemelt", "Professor", "US", false, 3,
				63, -9308, "(205) 2560799", "11 Walton Court", 2, "F"));
		tblGrid.add(new TableGrid("1e8289dc-2ef3-4045-ad6b-786d00368427", "Lexis Mostin", "Analyst Programmer", "FR",
				true, 4, 81, 38153, "(903) 8388089", "38547 Westend Way", 4, "F"));
		tblGrid.add(new TableGrid("797387bd-c247-48b3-97b6-5e75791f8809", "Felizio Gooda", "GIS Technical Architect",
				"DE", true, 3, 89, 81585, "(372) 2389397", "9 Summer Ridge Circle", 2, "M"));
		tblGrid.add(new TableGrid("24c541b0-4978-4072-84d0-abe94fcd0756", "Aubry Oxberry", "Financial Advisor", "BR",
				false, 2, 3, -6095, "(665) 4176083", "06 Lerdahl Point", 10, "F"));
		return tblGrid;
	}

	@Override
	public List<BarChart> retriveAll(int id) {
		ArrayList<BarChart> barChart = new ArrayList<BarChart>();
		barChart.add(new BarChart("Critical", 0));
		barChart.add(new BarChart("Blocker", 0));
		if(id==6) {
		barChart.add(new BarChart("Major", 55));
		}
		else {
			barChart.add(new BarChart("Major", 15));
		}
		return barChart;
	}



}
