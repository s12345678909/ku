package com.javatpoint;
import java.util.List;
public interface IProductService 
{
List<Product> findAll();
List<TableGrid> findAllTbl();
List<BarChart> retriveAll(int id);
}
