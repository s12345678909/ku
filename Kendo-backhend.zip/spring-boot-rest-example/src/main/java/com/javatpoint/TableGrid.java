package com.javatpoint;

public class TableGrid {
	public TableGrid()
	{
		
	}
	//constructor using fields
	public TableGrid(String id, String full_name, String job_title, String country,boolean is_online,int rating,int target,int budget,String phone,String address,int img_id,String gender) 
	{
	super();
	this.id = id;
	this.full_name=full_name;
	this.job_title=job_title;
	this.country=country;
	this.is_online=is_online;
	this.rating=rating;
	this.target=target;
	this.budget=budget;
	this.phone=phone;
	this.address=address;
	this.img_id=img_id;
	this.gender=gender;


	}
	
	private String id;
	private String full_name;
	private String job_title;
	private String country;
	private boolean is_online;
	private int rating;
	private int target;
	private int budget;
	private String phone;
	private String address;
	private int img_id;
	private String gender;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFull_name() {
		return full_name;
	}

	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}

	public String getJob_title() {
		return job_title;
	}

	public void setJob_title(String job_title) {
		this.job_title = job_title;
	}


	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public boolean isIs_online() {
		return is_online;
	}

	public void setIs_online(boolean is_online) {
		this.is_online = is_online;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public int getTarget() {
		return target;
	}

	public void setTarget(int target) {
		this.target = target;
	}

	public int getBudget() {
		return budget;
	}

	public void setBudget(int budget) {
		this.budget = budget;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getImg_id() {
		return img_id;
	}

	public void setImg_id(int img_id) {
		this.img_id = img_id;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

}
