import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComponentQualityComponent } from './component-quality.component';

describe('ComponentQualityComponent', () => {
  let component: ComponentQualityComponent;
  let fixture: ComponentFixture<ComponentQualityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ComponentQualityComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ComponentQualityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
