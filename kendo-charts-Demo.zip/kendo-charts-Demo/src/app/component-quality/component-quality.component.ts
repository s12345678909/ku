import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-component-quality',
  templateUrl: './component-quality.component.html',
  styleUrls: ['./component-quality.component.css']
})
export class ComponentQualityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  public series: any[] = [{
    name: '3DA Enablers',
    data: [82.6, 42.6]
  }, {
    name: 'Home Lending Document Services',
    data: [43.6, 43.6, 43.6, 6, 79.9]
  }, {
    name: 'Hazard',
    data: [77.7, 58.27, 58.27, 58.27, 58.27]
  }, {
    name: 'LOS Enablers',
    data: [45.9, 47.9, 46.5, 47.4, 50]
  },
  {
    name: 'Pricing',
    data: [35.6, 35.6, 35.6, 35.6]
  },
  {
    name: 'Rate Reduction Benfit',
    data: [94.07, 92.45, 90.17, 93.2, 87.35]
  },
  {
    name: 'Loan Management',
    data: [82.2, 82.2, 82.2, 82.7, 79.9]
  },
  {
    name: 'Loan',
    data: [83.6, 77.5, 80.6, 82.2, 23.43]
  },
  {
    name: 'EVT',
    data: [47.35, 47.4, 47.4, 0, 47.35]
  },
  {
    name: 'PQFI',
    data: [97.7, 97.7,97.7, 97.7, 96.05]
  }];
  public categories: string[] = ["NOVEMBER", "DECEMBER", "JANAUARY", "FEBRUARY", "MARCH"];

}
