import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DomainQualityComponent } from './domain-quality.component';

describe('DomainQualityComponent', () => {
  let component: DomainQualityComponent;
  let fixture: ComponentFixture<DomainQualityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DomainQualityComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DomainQualityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
