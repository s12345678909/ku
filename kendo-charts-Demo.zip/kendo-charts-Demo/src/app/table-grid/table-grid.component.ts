import { Component, OnInit ,ViewChild} from '@angular/core';
import { employees } from '../model/employees';
import { images } from '../images/images';
import { DataBindingDirective } from '@progress/kendo-angular-grid';
import { process } from '@progress/kendo-data-query'

import { MatSidenav } from '@angular/material/sidenav';

@Component({
  selector: 'app-table-grid',
  templateUrl: './table-grid.component.html',
  styleUrls: ['./table-grid.component.css']
})
export class TableGridComponent implements OnInit {
  @ViewChild(DataBindingDirective) dataBinding: DataBindingDirective;
  public gridData: any[] = employees;
  public gridView: any[];

  public mySelection: string[] = [];

  public ngOnInit(): void {
      this.gridView = this.gridData;
  }

  public onFilter(inputValue: string): void {
      this.gridView = process(this.gridData, {
          filter: {
              logic: "or",
              filters: [
                  {
                      field: 'full_name',
                      operator: 'contains',
                      value: inputValue
                  },
                  {
                      field: 'job_title',
                      operator: 'contains',
                      value: inputValue
                  },
                  {
                      field: 'budget',
                      operator: 'contains',
                      value: inputValue
                  },
                  {
                      field: 'phone',
                      operator: 'contains',
                      value: inputValue
                  },
                  {
                      field: 'address',
                      operator: 'contains',
                      value: inputValue
                  }
              ],
          }
      }).data;

      this.dataBinding.skip = 0;
  }

  private photoURL(dataItem: any): string {
      const code: string = dataItem.img_id + dataItem.gender;
      const image: any = images;

      return image[code];
  }

  private flagURL(dataItem: any): string {
      const code: string = dataItem.country;
      const image: any = images;

      return image[code];
  }
  title = 'sidennav';
  @ViewChild('sidenav')
  sidenav!: MatSidenav;
  isExpanded = true;
  showSubmenu: boolean = false;
  isShowing = false;
  showSubSubMenu: boolean = false;

  mouseenter() {
    if (!this.isExpanded) {
      this.isShowing = true;
    }
  }

  mouseleave() {
    if (!this.isExpanded) {
      this.isShowing = false;
    }
  }
}
